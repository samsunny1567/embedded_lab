/*
 * application.c
 *
 * Created: 12/23/2023 12:51:22 PM
 *  Author: PramodVariyam
 */ 

#include "macros.h"
#include "headers.h"
#include "extern.h"
#include "globals.h"
#include "application.h"

void application_init()
{
	initialize_peripherals();
	add_all_slave_commands();
}



void add_all_slave_commands()
{
	//slave_uart_add_command(TOF_SET_ENABLE, 1, 0, &set_tof_enable);

}
