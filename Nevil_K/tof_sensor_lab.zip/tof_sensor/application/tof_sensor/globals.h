/*
 * globals.h
 *
 * Created: 18-12-2023 12:19:29
 *  Author: Nevil
 */ 


#ifndef GLOBALS_H_
#define GLOBALS_H_

PIN_OBJ GPIO_0;
PIN_OBJ GPIO_1;
PIN_OBJ INT;
PIN_OBJ EN;

PIN_OBJ COM0;
PIN_OBJ TXD;
PIN_OBJ RXD;

PIN_OBJ SDA;
PIN_OBJ SCL;

USART_CONFIG SLAVE_UART;
TWI_CONFIG  TWI_0;
TWI_t  SLAVE_REGISTER;

uint8_t cal_data[14];
TCA_CONFIG TCA_0;

uint8_t no_of_dist;             // first byte of incoming data array, gives information about no.of limits
uint16_t distance_limits_t[10];   // array to store 10 16bit distance limits;
uint8_t dist_limit_index ;

typedef enum {
	parameter,
	response
}trans_type;

bool set_dist_measurement_mode_flag;

#define NUM_DISTANCE_LIMITS  10

#endif /* GLOBALS_H_ */