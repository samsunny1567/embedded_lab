/*
 * tmf8701_Driver.c
 *
 * Created: 05-01-2024 16:35:02
 *  Author: Nevil
 */ 

#include "headers.h"
#include "extern.h"
#include "globals.h"


extern TMF_CMD_DATA* CMD_DATA;

uint8_t data_to_tof[10];
uint8_t *(cb_fn)();

uint8_t update_tmf_gpio_cmd_setting(){
	return input_low_disable_collection;
}

uint8_t update_tmf_operating_mode(){// both proximity and combined mode
	uint8_t data=0;
	data =  (1 << proximity_enable_bp)
	|  (1 << distance_enable_bp)
	|  (1 << combine_proxi_distance_bp)
	|  (1 << donot_go_to_stdby_bp);
	return data;
}

uint8_t tmf_reporting_time_interval(){// cmd_data2
	uint8_t value =100; // update here for changing the repetition time
	return value;
}

uint8_t tmf_cal_algo_data_found(){
	uint8_t data;
	data = (1<<dataFactoryCal_bp)
	| (1<<dataAlgState_bp);
	return data;
}

uint8_t tmf_reserved_00(){
	return 0;
}

uint8_t tmf_reserved_ff(){
	return 0xff;
}

uint8_t tmf_gpio_config_as_vcsel_out(){
	return (uint8_t)no_signal;
}

void update_cmd_data_registers(uint8_t* cmd_data_register, uint8_t (*cb_fn)()){
	*cmd_data_register = cb_fn;
}

void update_all_tmf_commands(tmf_cmds index){
	update_cmd_data_registers(&param.tof_cmd[index].cmd_data0,&tmf_reserved_ff);
	update_cmd_data_registers(&param.tof_cmd[index].cmd_data1,&tmf_reserved_ff);
	update_cmd_data_registers(&param.tof_cmd[index].cmd_data2,&tmf_reporting_time_interval);
	update_cmd_data_registers(&param.tof_cmd[index].cmd_data3,&tmf_reserved_00);
	update_cmd_data_registers(&param.tof_cmd[index].cmd_data4,&tmf_gpio_config_as_vcsel_out);
	update_cmd_data_registers(&param.tof_cmd[index].cmd_data5,&update_tmf_gpio_cmd_setting);
	update_cmd_data_registers(&param.tof_cmd[index].cmd_data6,&update_tmf_operating_mode);
	if (index == CMD_0x02){
		update_cmd_data_registers(&param.tof_cmd[index].cmd_data7,&tmf_cal_algo_data_found);
	}
}

bool set_tof_enable(){
	setPinLevel(&INT,true);
	return (I2C_write1ByteRegister(&TWI_0,TMF8701_ADDRESS,ENABLE,1) == I2C_NOERR);
}

bool get_cpu_status(){
	while(I2C_read1ByteRegister(&TWI_0,TMF8701_ADDRESS,ENABLE) != 0x41);
	return true;
}

void start_factory_cal(){
	i2c_error_t data = I2C_write1ByteRegister(&TWI_0,TMF8701_ADDRESS,COMMAND,0x0A);
	while(I2C_read1ByteRegister(&TWI_0,TMF8701_ADDRESS,REGISTER_CONTENTS) != 0x0A);
	I2C_readDataBlock(&TWI_0,TMF8701_ADDRESS,FACTORY_CALIB_0,cal_data,NUM_DISTANCE_LIMITS);
}

bool load_factory_cal(){
	for (uint8_t i =0 ; i<14 ; i++){
		i2c_error_t er_flag = I2C_write1ByteRegister(&TWI_0,TMF8701_ADDRESS,(FACTORY_CALIB_0+i) , cal_data[i]);
	}
	return true;
}

void data_to_tof_cmds(tmf_cmds index,uint8_t* data){
	uint8_t* ptr = &param.tof_cmd[index].cmd_data0;
	for (uint8_t i = 0 ; i <= 10 ; i++){
		i2c_error_t data = I2C_write1ByteRegister(&TWI_0,TMF8701_ADDRESS,(CMD_DATA9+i),*(ptr+9-i));
	}
}

void tmf_init(){
	set_tof_enable();
	if(get_cpu_status()){
		if(load_factory_cal()){
			i2c_error_t err_t = I2C_write1ByteRegister(&TWI_0,TMF8701_ADDRESS,APPID,APP0_RUNNING);
			while(I2C_read1ByteRegister(&TWI_0,TMF8701_ADDRESS,APPID) != APP0_RUNNING);
			update_all_tmf_commands(CMD_0x02);
			data_to_tof_cmds(CMD_0x02,data_to_tof);
		}
	}
}
