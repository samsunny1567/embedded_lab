/*
 * tmf8701_Driver.h
 *
 * Created: 05-01-2024 16:35:13
 *  Author: Nevil
 */ 


#ifndef TMF8701_DRIVER_H_
#define TMF8701_DRIVER_H_


#define dataFactoryCal_bp  0
#define dataFactoryCal_bm  (1<<0)
#define dataAlgState_bp   1
#define dataAlgState_bm   (1<<1)

#define proximity_enable_bp  0
#define proximity_enable_bm  (1<<0)
#define distance_enable_bp   1
#define distance_enable_bm   (1<<1)
#define algImmediateInterrupt_bp  4
#define algImmediateInterrupt_bm  (1<<4)
#define combine_proxi_distance_bp   5
#define combine_proxi_distance_bm   (1<<5)
#define donot_go_to_stdby_bp   7
#define donot_go_to_stdby_bm   (1<<7)


/****************************ENUMS****************************************/

typedef enum{
	disabled = 0, //GPIO0 is not used for input or output.
	input_low_disable_collection = 1, //When the input signal goes low (0), it immediately stops the current measurement process and restart when  the input returns to high (1)
	input_high_disable_collection = 2, //When the input signal goes high (1), it immediately stops the current measurement process and restart when  the input returns to low (0)
	VCSEL_output_enable = 3, //VCSEL output is passed to gpio
	output_low = 4, //set gpio as output and state is low
	output_high = 5 //set gpio as output and state is high
	
}GPIO_settings;

typedef enum{
	no_signal        = 0,
	GPIO_rises_0us   = 1,
	GPIO_rises_100us = 2,
	GPIO_rises_200us = 3
}VCSEL_output_settings;

typedef enum
{
	CMD_0x02 = 0,
	CMD_0x03,
	//	CMD_0x04,
}tmf_cmds;



/****************************STRUCTURES***********************************/

typedef struct{
	uint8_t cmd_data0;
	uint8_t cmd_data1;
	uint8_t cmd_data2;
	uint8_t cmd_data3;
	uint8_t cmd_data4;
	uint8_t cmd_data5;
	uint8_t cmd_data6;
	uint8_t cmd_data7;
	uint8_t cmd_data8;
	uint8_t cmd_data9;
}TMF_CMD_DATA;

typedef struct{
	uint8_t tmf_cmd_index;
	TMF_CMD_DATA tof_cmd[5];
}tmf_DATA;


/**************************************************************************/

TMF_CMD_DATA* CMD_DATA;

tmf_DATA param;


/*************************************************************************/


uint8_t update_tmf_gpio_cmd_setting();
uint8_t update_tmf_operating_mode();
uint8_t tmf_reporting_time_interval();
uint8_t tmf_cal_algo_data_found();
uint8_t tmf_reserved_00();
uint8_t tmf_reserved_ff();
uint8_t tmf_gpio_config_as_vcsel_out();

void update_cmd_data_registers(uint8_t* cmd_data_register, uint8_t (*cb_fn)());
void update_all_tmf_commands(tmf_cmds index);

bool set_tof_enable();
bool get_cpu_status();
void start_factory_cal();
bool load_factory_cal();
void data_to_tof_cmds(tmf_cmds index,uint8_t* data);
void tmf_init();


#endif /* TMF8701_DRIVER_H_ */