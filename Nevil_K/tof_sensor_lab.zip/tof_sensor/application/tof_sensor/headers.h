/*
 * headers.h
 *
 * Created: 12/18/2023 12:40:33 PM
 *  Author: samsunny
 */ 


#ifndef HEADERS_H_
#define HEADERS_H_


#include <avr/io.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>
 #include <compiler.h>
#include "systemDriver/systemDriver.h"
#include "gpioDriver/gpioDriver.h"
#include "usartDriver/fullDuplexUsartDriver.h"
#include "usartSlave/usartSlave.h"
#include "twiDriver/twiDriver.h"
#include "timerDriver/tcaDriver.h"
#include "timerDriver/tcbDriver.h"
#include "twidriver/twiDriver.h"
#include "twidriver/i2cDriver.h"
#include "twidriver/i2cMaster.h"
#include "twidriver/i2c_types.h"
#include "tmf8701.h"
#include "uart_commands.h"


#include "tmf8701_Driver.h"

#endif /* HEADERS_H_ */