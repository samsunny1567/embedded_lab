/*
 * macros.h
 *
 * Created: 12/22/2023 7:01:44 AM
 *  Author: PramodVariyam
 */ 


#ifndef MACROS_H_
#define MACROS_H_

#define F_CPU 20000000

#define BAUD_RATE 9600


#endif /* MACROS_H_ */