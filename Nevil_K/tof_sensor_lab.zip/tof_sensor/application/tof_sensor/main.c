/*
 * tof_sensor.c
 *
 * Created: 12/11/2023 9:14:55 PM
 * Author : PramodVariyam
 */ 

#include <avr/io.h>
#include "headers.h"
#include "globals.h"
#include "application.h"

int main(void)
{
	application_init();
	tmf_init();
    /* Replace with your application code */
    while (1) 
    {
		process_uart_command();
    }
}


