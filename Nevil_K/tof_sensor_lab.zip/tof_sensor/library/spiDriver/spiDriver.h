/*
 * spiDriver.h
 *
 * Created: 10/20/2023 1:49:05 PM
 *  Author: BenSchnuck
 */ 


#ifndef SPIDRIVER_H_
#define SPIDRIVER_H_

#define MAX_SLAVES 10

/** Status of the SPI hardware and SPI bus.*/
typedef enum spi_transfer_status {
	SPI_FREE, ///< SPI hardware is not open, bus is free.
	SPI_IDLE, ///< SPI hardware has been opened, no transfer ongoing.
	SPI_BUSY, ///< SPI hardware has been opened, transfer ongoing.
	SPI_DONE  ///< SPI hardware has been opened, transfer complete.
} spi_transfer_status_t;

typedef enum spi_transfer_type {
	SPI_EXCHANGE, ///< SPI transfer is bidirectional
	SPI_READ,     ///< SPI transfer reads, writes only 0s
	SPI_WRITE     ///< SPI transfer writes, discards read data
} spi_transfer_type_t;

/*
	Config object for CTRLA register for SPI
*/
typedef struct {
	bool DORD;
	bool MASTER;
	bool CLK2X;
	SPI_PRESC_t PRESC;
	bool ENABLE;
}SPI_CTRLA_CONFIG;

/*
	Config object for CTRLB register for SPI
*/
typedef struct {
	bool BUFFEN;
	bool BUFWR;
	bool SSD;
	SPI_MODE_t MODE;
}SPI_CTRLB_CONFIG;

/*
	Config object for INTCTRL register for SPI
*/
typedef struct {
	bool RXCIE;
	bool TXCIE;
	bool DREIE;
	bool SSIE;
	bool IE;
}SPI_INTCTRL_CONFIG;

/*
	Config object for SPI
*/
typedef struct {
	SPI_t* spi;
	spi_transfer_status_t status;
	spi_transfer_type_t type;
	uint8_t* data;
	uint8_t size;
	PIN_OBJ SS[MAX_SLAVES];
	uint8_t active_SS_index;
	
	SPI_CTRLA_CONFIG CTRLA;
	SPI_CTRLB_CONFIG CTRLB;
	SPI_INTCTRL_CONFIG INTCTRL;
}SPI_CONFIG;

/*
	void setSpiCTRLA
	Update the SPI's CTRLA register with the passed config settings
	
	config - SPI_CONFIG settings object
*/
static inline void setSpiCTRLA(SPI_CONFIG config) {
	config.spi->CTRLA = config.CTRLA.CLK2X << SPI_CLK2X_bp
						| config.CTRLA.DORD << SPI_DORD_bp
						| config.CTRLA.ENABLE << SPI_ENABLE_bp
						| config.CTRLA.MASTER << SPI_MASTER_bp
						| config.CTRLA.PRESC << SPI_PRESC_gp;
}

/*
	void setSpiCTRLB
	Update the SPI's CTRLB register with the passed config settings
	
	config - SPI_CONFIG settings object
*/
static inline void setSpiCTRLB(SPI_CONFIG config) {
	config.spi->CTRLB = config.CTRLB.BUFFEN << SPI_BUFEN_bp
						| config.CTRLB.BUFWR << SPI_BUFWR_bp
						| config.CTRLB.MODE << SPI_MODE_gp
						| config.CTRLB.SSD << SPI_SSD_bp;
}

/*
	void setSpiINTCTRL
	Update the SPI's INTCTRL register with the passed config settings
	
	config - SPI_CONFIG settings object
*/
static inline void setSpiINTCTRL(SPI_CONFIG config) {
	config.spi->INTCTRL = config.INTCTRL.DREIE << SPI_DREIE_bp
						| config.INTCTRL.IE << SPI_IE_bp
						| config.INTCTRL.RXCIE << SPI_RXCIE_bp
						| config.INTCTRL.SSIE << SPI_SSIE_bp
						| config.INTCTRL.TXCIE << SPI_TXCIE_bp;
}

/*
	void updateSpiRegisters
	Update all the SPI registers with the passed config settings
	
	config - SPI_CONFIG settings object
*/
static inline void updateSpiRegisters(SPI_CONFIG config) {
	setSpiCTRLA(config);
	setSpiCTRLB(config);
	setSpiINTCTRL(config);
}

/*
	bool checkSpiSS
	Check if a SlaveSelect pin in the config object is valid
	
	config - SPI_CONFIG settings object
	pin_index - index to check in the SS array
*/
static inline bool checkSpiSS(SPI_CONFIG config, uint8_t pin_index) {
	return (config.SS[pin_index].port != NULL);
}

/*
	bool setupSpiSS
	Setup a pin for slave select and return true if successful, false if unsuccessful
	
	config - SPI_CONFIG settings object
	pin_index - index in SS array to edit
	vport - pointer to vport object to assign to object in SS array
	pin_num - pin number to assign to object in SS array
*/
static inline bool setupSpiSS(SPI_CONFIG config, uint8_t pin_index, PIN_PORTS vport, uint8_t pin_num) {
	if (pin_index >= MAX_SLAVES) return false;
	if (!instantiatePin(&config.SS[pin_index], vport, pin_num)) return false;
	
	setPinLevel(&config.SS[pin_index], false);
	setPinDir(&config.SS[pin_index], PORT_DIR_OUT);
	
	return true;
}

/*
	void setSpiSS
	Set SS pin high/low based on given pin index and enable value
	
	config - SPI_CONFIG settings object
	pin_index - index in SS array to edit
	enable - state of the SS pin to set
*/
static inline void setSpiSS(SPI_CONFIG config, uint8_t pin_index, bool enable) {
	setPinLevel(&config.SS[pin_index], enable);
	return;
}

/*
	bool setupSpiPins
	Setup MISO and MOSI pins with concrete pin numbers and initialize them. Also setup SCLK obj.
	
	MISO - MISO pin object
	MOSI - MOSI pin object
	SCLK - SCLK pin object
	altpins - boolean to choose regular or alternate pin numbers
*/
static inline bool setupSpiPins(PIN_OBJ MISO, PIN_OBJ MOSI, PIN_OBJ SCLK, bool altpins) {
	if(altpins) {
		PORTMUX.TWISPIROUTEA |= PORTMUX_SPI00_bm;
		
		MISO.pin = 1;
		MOSI.pin = 0;
		MISO.port = &VPORTC;
		MOSI.port = &VPORTC;
		SCLK.pin = 2;
		SCLK.port = &VPORTC;
	} else {
		MISO.pin = 5;
		MOSI.pin = 4;
		MISO.port = &VPORTA;
		MOSI.port = &VPORTA;
		SCLK.pin = 6;
		SCLK.port = &VPORTA;
	}
	setPinDir(&MISO, PORT_DIR_IN);
	setPinPullMode(&MISO, PORT_PULL_OFF);
	
	setPinLevel(&MOSI, false);
	setPinDir(&MOSI, PORT_DIR_OUT);
	
	return true;
}

// Function Declarations
void defaultSpiConfigSettings(SPI_CONFIG* config);
void spiInit(SPI_CONFIG config, SPI_t* spi, bool altPins);
void spiEnable(SPI_CONFIG config);
void spiDisable(SPI_CONFIG config);
void spiDefaultISR(SPI_CONFIG config);
bool spiStatusFree(SPI_CONFIG config);
bool spiStatusIdle(SPI_CONFIG config);
bool spiStatusBusy(SPI_CONFIG config);
bool spiStatusDone(SPI_CONFIG config);
uint8_t spiExchangeByte(SPI_CONFIG config, uint8_t data, uint8_t slave_select_index);
void spiExchangeBlock(SPI_CONFIG config, void *block, uint8_t size, uint8_t slave_select_index);
void spiWriteBlock(SPI_CONFIG config, void *block, uint8_t size, uint8_t slave_select_index);
void spiReadBlock(SPI_CONFIG config, void *block, uint8_t size, uint8_t slave_select_index);

#endif /* SPIDRIVER_H_ */