/*
 * usartDriver.c
 *
 * Created: 10/17/2023 2:29:18 PM
 * Author : BenSchnuck
 */ 
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <avr/io.h>
#include "gpioDriver.h"
#include "fullDuplexUsartDriver.h"

//bool setupUsartPin(PIN_OBJ pin);
//bool setupUsartPins(PIN_OBJ rxPin, PIN_OBJ txPin);
//uint8_t USART_get_data(USART_CONFIG config);
/**
 * \brief Enter a critical region
 * 
 * Saves the contents of the status register, including the Global 
 * Interrupt Enable bit, so that it can be restored upon leaving the 
 * critical region. Thereafter, clears the Global Interrupt Enable Bit.
 * This macro takes a parameter P that is unused for the GCC compiler,
 * but necessary for code compatibility with the IAR compiler. The IAR
 * compiler declares a variable with the name of the parameter for
 * holding the SREG value. Since a variable is declared in the macro,
 * this variable must have a name that is unique within the scope
 * that the critical region is declared within, otherwise compilation 
 * will fail.
 *
 * \param[in] UNUSED(GCC)/P(IAR) Name of variable storing SREG
 *
 */

#define ENTER_CRITICAL(UNUSED) __asm__ __volatile__ (   \
   "in __tmp_reg__, __SREG__"                    "\n\t" \
   "cli"                                         "\n\t" \
   "push __tmp_reg__"                            "\n\t" \
   ::: "memory"                                         \
   )

/**
 * \brief Exit a critical region
 * 
 * Restores the contents of the status register, including the Global 
 * Interrupt Enable bit, as it was when entering the critical region.
 * This macro takes a parameter P that is unused for the GCC compiler,
 * but necessary for code compatibility with the IAR compiler. The IAR
 * compiler uses this parameter as the name of a variable that holds 
 * the SREG value. The parameter must be identical to the parameter 
 * used in the corresponding ENTER_CRITICAL().
 *
 * \param[in] UNUSED(GCC)/P(IAR) Name of variable storing SREG
 *
 */

#define EXIT_CRITICAL(UNUSED)  __asm__ __volatile__ (   \
   "pop __tmp_reg__"                             "\n\t" \
   "out __SREG__, __tmp_reg__"                   "\n\t" \
   ::: "memory"                                         \
   )



/*
	Note: This function requires the use of the gpioDriver
	bool setupUsartPin
	Check if pins are valid and setup USART pins through PORTMUX 
	
	returns false if pin is invalid for usart communication
	returns true if pin is successfully setup
	
	pin - Pin object to setup. For more information look to gpioDriver.h
	
*/
bool setupUsartPin(PIN_OBJ pin) {
	if (pin.port_enum == PIN_PORTA) {
		if(pin.pin == 4 || pin.pin == 5) {
			PORTMUX.USARTROUTEA |= PORTMUX_USART0_ALT1_gc;
			return true;
		}
		else if(pin.pin == 0 || pin.pin == 1) {
			return true;	
		}
	} else if (pin.port_enum == PIN_PORTB) {
		if(pin.pin == 4 || pin.pin == 5) {
			PORTMUX.USARTROUTEA |= PORTMUX_USART3_ALT1_gc;
			return true;
		}
		else if(pin.pin == 0 || pin.pin == 1) {
			return true;
		}
	} else if (pin.port_enum == PIN_PORTC) {
		if(pin.pin == 4 || pin.pin == 5) {
			PORTMUX.USARTROUTEA |= PORTMUX_USART1_ALT1_gc;
			return true;
		}
		else if(pin.pin == 0 || pin.pin == 1) {
			return true;
		}
	} else if (pin.port_enum == PIN_PORTF) {
		if(pin.pin == 4 || pin.pin == 5) {
			PORTMUX.USARTROUTEA |= PORTMUX_USART2_ALT1_gc;
			return true;
		}
		else if(pin.pin == 0 || pin.pin == 1) {
			return true;
		}
	}
	
	return false;
}

/*
	Note: This function requires the use of the gpioDriver
	bool setupUsartPins
	Setup both RX and TX pins for USART. Verifies pins are valid and sets up PORTMUX, pin 
	direction, and level.
	
	returns false if one or both pins are invalid
	returns true if both pins are setup successfully
	
	rxPin - RX Pin object to setup. For more information look to gpioDriver.h
	txPin - TX Pin object to setup. For more information look to gpioDriver.h
*/
bool setupUsartPins(PIN_OBJ rxPin, PIN_OBJ txPin) {
	if(setupUsartPin(rxPin) && setupUsartPin(txPin)) {
		initializeInputPin(rxPin, PORT_PULL_OFF);
		initializeOutputPin(txPin, false, PORT_PULL_OFF);
		return true;
	}
	return false;
}

/*
	void setUsart_CTRLA
	Update USART's _CTRLA register with the passed config settings
	
	config - USART_CONFIG settings object
*/
void USART_set_CTRLA(USART_CONFIG* config) {
	config->usart->CTRLA = config->_CTRLA.RXCIE << USART_RXCIE_bp
						| config->_CTRLA.TXCIE << USART_TXCIE_bp
						| config->_CTRLA.DREIE << USART_DREIE_bp
						| config->_CTRLA.RXSIE << USART_RXSIE_bp
						| config->_CTRLA.LBME << USART_LBME_bp
						| config->_CTRLA.ABEIE << USART_ABEIE_bp
						| config->_CTRLA.RS485 << USART_RS485_gp;
}

/*
	void setUsart_CTRLB
	Update USART's _CTRLB register with the passed config settings
	
	config - USART_CONFIG settings object
*/
void USART_set_CTRLB(USART_CONFIG* config) {
	config->usart->CTRLB = config->_CTRLB.RXEN << USART_RXEN_bp
						| config->_CTRLB.TXEN << USART_TXEN_bp
						| config->_CTRLB.SFDEN << USART_SFDEN_bp
						| config->_CTRLB.ODME << USART_ODME_bp
						| config->_CTRLB.RXMODE << USART_RXMODE_gp
						| config->_CTRLB.MPCM << USART_MPCM_bp;
}

/*
	uint8_t USART_get_data
	Get data from the USART object's RXDATAL register
	
	config - USART_CONFIG object containing USART settings
*/
uint8_t USART_get_data(USART_CONFIG config) {
	return config.usart->RXDATAL;
}

/*
	void setUsartBaud
	Update USART's BAUD rate based on the config's set cpu clock, clock divisor, and chosen baud rate
	
	config - USART_CONFIG settings object
*/
void setUsartBaud(USART_CONFIG config) {
	config.usart->BAUD = (uint16_t)(((float)(config._cpu_clk / config._clk_divisor) * 64 / (16 * (float)config._baud_rate)) + 0.5);
}


/*
	Note: This function requires gpioDriver
	void instantiateUSART
	Setup empty USART config object with passed rx/tx pins and usart pointer

	config - pointer to USART_CONFIG object containing USART settings
	usart - pointer to USART_t object to assign to UART config
	rxPin - RX Pin object to setup. For more information look to gpioDriver.h
	txPin - TX Pin object to setup. For more information look to gpioDriver.h
	baud_rate - Baud rate of the USART
*/
void USART_instantiate(USART_CONFIG* config, USART_t* usart, PIN_OBJ rxPin, PIN_OBJ txPin,  uint16_t baud_rate, float cpu_clk) {
	config->usart = usart;
	config->_baud_rate = baud_rate;
	config->_cpu_clk =  cpu_clk;
	config->_clk_divisor = 1;
	// pin setup
	setupUsartPins(rxPin, txPin);
}

/*
	void USART_init
	Initialize USART based off passed config
	
	config - pointer to USART_CONFIG object containing USART settings
*/
void USART_initialize(USART_CONFIG* config) {
	uint8_t tmp;
	
	setUsartBaud(*config);
	config->_CTRLA.RXCIE = true;
	config->_CTRLA.DREIE = true;
	config->_CTRLB.RXEN = true;
	config->_CTRLB.TXEN = true;
	USART_set_CTRLA(config);
	USART_set_CTRLB(config);
	
	// Flush the RX buffer
	tmp = config->usart->RXDATAL;
	while (config->usart->RXDATAH & USART_RXCIE_bm)
		tmp = config->usart->RXDATAL;
	tmp = tmp + 1; // to avoid compilation warning	
	
	config->_USART_rx_tail		= 0;
	config->_USART_rx_head		= 0;
	config->_USART_rx_elements	= 0;
	config->_USART_tx_tail		= 0;
	config->_USART_tx_head		= 0;
	config->_USART_tx_elements	= 0;
}

/*
	void USART_default_rx_isr
	Default ISR for USART RX
	
	config - USART_CONFIG object containing USART settings
*/
void USART_default_rx_isr(USART_CONFIG* config) {
	uint8_t data;
	uint8_t tmphead;
	
	data = USART_get_data(*config);
	
	tmphead = (config->_USART_rx_head + 1) & USART_RX_BUFFER_MASK;
	
	if (tmphead == config->_USART_rx_tail) {
		// buffer overflow
	} else {
		config->_USART_rx_head = tmphead;
		
		config->_USART_rxbuf[tmphead] = data;
		config->_USART_rx_elements++;
	}
}

/*
	void USART_default_udre_isr
	Default ISR for USART TX (UDRE)
	
	config - USART_CONFIG object containing USART settings
*/
void USART_default_tx_isr(USART_CONFIG* config) {
	uint8_t tmptail;
	
	if (config->_USART_tx_elements != 0) {
		tmptail = (config->_USART_tx_tail + 1) & USART_TX_BUFFER_MASK;
		config->_USART_tx_tail = tmptail;
		
		//transmit
		config->usart->TXDATAL = config->_USART_txbuf[tmptail];
		config->_USART_tx_elements--;
	}
	
	if(config->_USART_tx_elements == 0) {
		// disable the int
		config->_CTRLA.DREIE = false;
		USART_set_CTRLA(config);
	}
}

/*
	uint8_t USART_read
	Read from the USART rx buffer and return the value
	
	config - USART_CONFIG object containing USART settings
*/
void USART_read(USART_CONFIG* config, uint8_t* data) {
	uint8_t tmptail;
	
	while (config->_USART_rx_elements == 0);
	
	tmptail = (config->_USART_rx_tail + 1) & USART_RX_BUFFER_MASK;
	
	config->_USART_rx_tail = tmptail;
	ENTER_CRITICAL(R);
	config->_USART_rx_elements--;
	EXIT_CRITICAL(R);
	
	*data = config->_USART_rxbuf[tmptail];
}

/*
	void USART_read_n
	Read n bytes from USART rx buffer
	This will block until n bytes are read
	
	config - pointer to USART_CONFIG object containing the USART settings
	dataOut - array to store data in
	n - number of bytes to read from USART
*/
void USART_read_n(USART_CONFIG* config, uint8_t* dataOut, uint16_t n) {
	uint16_t i;
	
	for(i=0; i<n; i++) 
		 USART_read(config, &(dataOut[i]));
}

/*
	void USART_write
	Write to USART tx buffer from config txbuf array
	
	config - USART_CONFIG object containing USART settings
	data - data to write to tx buffer
*/
void USART_write(USART_CONFIG* config, const uint8_t data) {
	uint8_t tmphead;
	
	tmphead = (config->_USART_tx_head + 1) & USART_TX_BUFFER_MASK;
	
	while (config->_USART_tx_elements == USART_TX_BUFFER_SIZE);
	
	config->_USART_txbuf[tmphead] = data;
	config->_USART_tx_head = tmphead;
	ENTER_CRITICAL(W);
	config->_USART_tx_elements++;
	EXIT_CRITICAL(W);
	
	config->_CTRLA.DREIE = 1;
	USART_set_CTRLA(config);
}

/*
	void USART_write_n
	Write n bytes to USART tx buffer
	
	config - USART_CONFIG object containing USART settings
	data - pointer to data/data array
	n - number of bytes to write
*/
void USART_write_n(USART_CONFIG* config, uint8_t* data, uint16_t n) {
	uint16_t i;
	for(i=0; i<n; i++) {
		USART_write(config, data[i]);
	}
}

/*
	void USART_enable
	Enable USART RX and TX
	
	config - USART_CONFIG object containing USART settings
*/
void USART_enable(USART_CONFIG* config) {
	config->_CTRLB.RXEN = true;
	config->_CTRLB.TXEN = true;
	USART_set_CTRLB(config);
}

/*
	void USART_enable_rx
	Enable USART RX
	
	config - USART_CONFIG object containing USART settings
*/
void USART_enable_rx(USART_CONFIG* config) {
	config->_CTRLB.RXEN = true;
	USART_set_CTRLB(config);
}

/*
	void USART_enable_tx
	Enable USART TX
	
	config - USART_CONFIG object containing USART settings
*/
void USART_enable_tx(USART_CONFIG* config) {
	config->_CTRLB.TXEN = true;
	USART_set_CTRLB(config);
}

/*
	void USART_disable
	Disable USART RX and TX
	
	config - USART_CONFIG object containing USART settings
*/
void USART_disable(USART_CONFIG* config) {
	config->_CTRLB.RXEN = false;
	config->_CTRLB.TXEN = false;
	USART_set_CTRLB(config);
}

void USART_RX_interrupt(USART_CONFIG* config, bool enable)
{
	config->_CTRLA.RXCIE = enable;
	USART_set_CTRLA(config);
}

void USART_TX_interrupt(USART_CONFIG* config, bool enable)
{
	config->_CTRLA.DREIE = enable;
	USART_set_CTRLA(config);
}