/*
 * fullDuplexUsartDriver.h
 *
 * Created: 10/17/2023 2:34:25 PM
 *  Author: BenSchnuck
 */ 


#ifndef FULLDUPLEXUSARTDRIVER_H_
#define FULLDUPLEXUSARTDRIVER_H_


#define USART_RX_BUFFER_SIZE 256
#define USART_TX_BUFFER_SIZE 256
#define USART_RX_BUFFER_MASK (USART_RX_BUFFER_SIZE - 1)
#define USART_TX_BUFFER_MASK (USART_TX_BUFFER_SIZE - 1)

/*
	Config object for CTRLA register of USART
*/
typedef struct {
	bool RXCIE;
	bool TXCIE;
	bool DREIE;
	bool RXSIE;
	bool LBME;
	bool ABEIE;
	USART_RS485_t RS485;
}USART_CTRLA;

/*
	Config object for CTRLB register of USART
*/
typedef struct {
	bool RXEN;
	bool TXEN;
	bool SFDEN;
	bool ODME;
	USART_RXMODE_t RXMODE;
	bool MPCM;
}USART_CTRLB;

/*
	Config object for USART
*/
typedef struct {
	USART_t* usart;

	// All private variables
	USART_CTRLA _CTRLA;
	USART_CTRLB _CTRLB;
	float _cpu_clk;
	uint16_t _clk_divisor;
	uint16_t _baud_rate;
	uint8_t _USART_rxbuf[USART_RX_BUFFER_SIZE];
	uint8_t _USART_rx_head;
	uint8_t _USART_rx_tail;
	uint8_t _USART_rx_elements;
	uint8_t _USART_txbuf[USART_TX_BUFFER_SIZE];
	uint8_t _USART_tx_head;
	uint8_t _USART_tx_tail;
	uint8_t _USART_tx_elements;
}USART_CONFIG;

// Function Declarations

void USART_instantiate(USART_CONFIG* config, USART_t* usart, PIN_OBJ rxPin, PIN_OBJ txPin, uint16_t baud_rate, float cpu_clk);
void USART_initialize(USART_CONFIG* config);

void USART_enable(USART_CONFIG* config);
void USART_enable_rx(USART_CONFIG* config);
void USART_enable_tx(USART_CONFIG* config);
void USART_disable(USART_CONFIG* config);

void USART_read(USART_CONFIG* config, uint8_t* data);
void USART_read_n(USART_CONFIG* config, uint8_t* dataOut, uint16_t n);
void USART_write(USART_CONFIG* config, const uint8_t data);
void USART_write_n(USART_CONFIG* config, uint8_t* data, uint16_t n);

void USART_RX_interrupt(USART_CONFIG* config, bool enable);
void USART_TX_interrupt(USART_CONFIG* config, bool enable);
void USART_default_rx_isr(USART_CONFIG* config);
void USART_default_tx_isr(USART_CONFIG* config);

#endif /* FULLDUPLEXUSARTDRIVER_H_ */