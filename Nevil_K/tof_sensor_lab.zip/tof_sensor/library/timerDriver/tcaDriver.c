/*
 * tcaDriver.c
 *
 * Created: 10/27/2023 1:52:51 PM
 *  Author: BenSchnuck
 */ 

#include "util.h"
#include "tcaDriver.h"


/*
	void setTcaCTRLD
	Update TCA's CTRLD register with passed config settings
	
	config - TCA_CONFIG object containing settings for TCA
*/
void setTcaCTRLD(TCA_CONFIG config) {
	if(config.split_mode) {
		config.tca->SPLIT.CTRLD = config.SPLIT.CTRLD.SPLITM << TCA_SPLIT_SPLITM_bp;
		} else {
		config.tca->SINGLE.CTRLD = config.SINGLE.CTRLD.SPLITM << TCA_SINGLE_SPLITM_bp;
	}
}

void enableTcaSplitMode(TCA_CONFIG config, bool enable) {
	config.split_mode = enable;
	config.SINGLE.CTRLD.SPLITM = enable;
	config.SPLIT.CTRLD.SPLITM = enable;
	setTcaCTRLD(config);
}

/*
	void setTcaCTRLA
	Update TCA's CTRLA register with passed config settings
	
	config - TCA_CONFIG object containing settings for TCA
*/
void setTcaCTRLA(TCA_CONFIG config) {
	if(config.split_mode) {
		config.tca->SPLIT.CTRLA = config.SPLIT.CTRLA.CLKSEL << TCA_SPLIT_CLKSEL_gp
							| config.SPLIT.CTRLA.ENABLE << TCA_SPLIT_ENABLE_bp;
	} else {
		config.tca->SINGLE.CTRLA = config.SINGLE.CTRLA.CLKSEL << TCA_SINGLE_CLKSEL_gp
							| config.SINGLE.CTRLA.ENABLE << TCA_SINGLE_ENABLE_bp;
	}
}

/*
	void setTcaCTRLB
	Update TCA's CTRLB register with passed config settings
	
	config - TCA_CONFIG object containing settings for TCA
*/
void setTcaCTRLB(TCA_CONFIG config) {
	if(config.split_mode) {
		config.tca->SPLIT.CTRLB = config.SPLIT.CTRLB.HCMP2EN << TCA_SPLIT_HCMP2EN_bp
								| config.SPLIT.CTRLB.HCMP1EN << TCA_SPLIT_HCMP1EN_bp
								| config.SPLIT.CTRLB.HCMP0EN << TCA_SPLIT_HCMP0EN_bp
								| config.SPLIT.CTRLB.LCMP2EN << TCA_SPLIT_LCMP2OV_bp
								| config.SPLIT.CTRLB.LCMP1EN << TCA_SPLIT_LCMP1EN_bp
								| config.SPLIT.CTRLB.LCMP0EN << TCA_SPLIT_LCMP0EN_bp;
	} else {
		config.tca->SINGLE.CTRLB = config.SINGLE.CTRLB.WGMODE
								| config.SINGLE.CTRLB.CMP2EN << TCA_SINGLE_CMP2EN_bp
								| config.SINGLE.CTRLB.CMP1EN << TCA_SINGLE_CMP1EN_bp
								| config.SINGLE.CTRLB.CMP0EN << TCA_SINGLE_CMP0EN_bp
								| config.SINGLE.CTRLB.ALUPD << TCA_SINGLE_ALUPD_bp;
	}
}

/*
	void setTcaCTRLC
	Update TCA's CTRLC register with passed config settings
	
	config - TCA_CONFIG object containing settings for TCA
*/
void setTcaCTRLC(TCA_CONFIG config) {
	if(config.split_mode) {
		config.tca->SPLIT.CTRLC = config.SPLIT.CTRLC.HCMP2OV << TCA_SPLIT_HCMP2OV_bp
								| config.SPLIT.CTRLC.HCMP1OV << TCA_SPLIT_HCMP1OV_bp
								| config.SPLIT.CTRLC.HCMP0OV << TCA_SPLIT_HCMP0OV_bp
								| config.SPLIT.CTRLC.LCMP2OV << TCA_SPLIT_LCMP2OV_bp
								| config.SPLIT.CTRLC.LCMP1OV << TCA_SPLIT_LCMP1OV_bp
								| config.SPLIT.CTRLC.LCMP0OV << TCA_SPLIT_LCMP0OV_bp;
	} else {
		config.tca->SINGLE.CTRLC = config.SINGLE.CTRLC.CMP2OV << TCA_SINGLE_CMP2OV_bp
								| config.SINGLE.CTRLC.CMP1OV << TCA_SINGLE_CMP1OV_bp
								| config.SINGLE.CTRLC.CMP2OV << TCA_SINGLE_CMP0OV_bp;
	}
}

/*
	void setTcaCTRLECLR
	Update TCA's CTRLECLR register with passed config settings
	
	config - TCA_CONFIG object containing settings for TCA
*/
void setTcaCTRLECLR(TCA_CONFIG config) {
	if(config.split_mode) {
		config.tca->SPLIT.CTRLECLR = config.SPLIT.CTRLECLR.CMDEN
								| config.SPLIT.CTRLECLR.CMD << TCA_SPLIT_CMD_gp;
	} else {
		config.tca->SINGLE.CTRLECLR = config.SINGLE.CTRLECLR.CMD << TCA_SINGLE_CMD_gp
								| config.SINGLE.CTRLECLR.LUPD << TCA_SINGLE_LUPD_bp
								| config.SINGLE.CTRLECLR.DIR << TCA_SINGLE_DIR_bp;
	}
}

/*
	void setTcaCTRLESET
	Update TCA's CTRLESET register with passed config settings
	
	config - TCA_CONFIG object containing settings for TCA
*/
void setTcaCTRLESET(TCA_CONFIG config) {
	if (config.split_mode) {
		config.tca->SPLIT.CTRLESET = config.SPLIT.CTRLESET.CMD << TCA_SPLIT_CMD_gp
									| config.SPLIT.CTRLESET.CMDEN;
	} else {
		config.tca->SINGLE.CTRLESET = config.SINGLE.CTRLESET.CMD << TCA_SINGLE_CMD_gp
									| config.SINGLE.CTRLESET.LUPD << TCA_SINGLE_LUPD_bp
									| config.SINGLE.CTRLESET.DIR << TCA_SINGLE_DIR_bp;
	}
}

/*
	void setTcaCTRLFCLR
	Update TCA's CTRLFCLR register with passed config settings
	
	config - TCA_CONFIG object containing settings for TCA
*/
void setTcaCTRLFCLR(TCA_CONFIG config) {
	if (!config.split_mode) {
		config.tca->SINGLE.CTRLFCLR = config.SINGLE.CTRLFCLR.CMP2BV << TCA_SINGLE_CMP2BV_bp
									| config.SINGLE.CTRLFCLR.CMP1BV << TCA_SINGLE_CMP1BV_bp
									| config.SINGLE.CTRLFCLR.CMP0BV << TCA_SINGLE_CMP0BV_bp
									| config.SINGLE.CTRLFCLR.PERBV << TCA_SINGLE_PERBV_bp;
	}
}

/*
	void setTcaCTRLFSET
	Update TCA's CTRLFSET register with passed config settings
	
	config - TCA_CONFIG object containing settings for TCA
*/
void setTcaCTRLFSET(TCA_CONFIG config) {
	if (!config.split_mode) {
		config.tca->SINGLE.CTRLFSET = config.SINGLE.CTRLFSET.CMP2BV << TCA_SINGLE_CMP2BV_bp
									| config.SINGLE.CTRLFSET.CMP1BV << TCA_SINGLE_CMP1BV_bp
									| config.SINGLE.CTRLFSET.CMP0BV << TCA_SINGLE_CMP0BV_bp
									| config.SINGLE.CTRLFSET.PERBV << TCA_SINGLE_PERBV_bp;
	}
}

/*
	void setTcaEVCTRL
	Update TCA's EVCTRL register with passed config settings
	
	config - TCA_CONFIG object containing settings for TCA
*/
void setTcaEVCTRL(TCA_CONFIG config) {
	if (!config.split_mode) {
		config.tca->SINGLE.EVCTRL = config.SINGLE.EVCTRL.EVACT << TCA_SINGLE_EVACT_gp
									| config.SINGLE.EVCTRL.CNTEI << TCA_SINGLE_CNTEI_bp;
	}
}

/*
	void setTcaINTCTRL
	Update TCA's INTCTRL register with passed config settings
	
	config - TCA_CONFIG object containing settings for TCA
*/
void setTcaINTCTRL(TCA_CONFIG config) {
	if(config.split_mode) {
		config.tca->SPLIT.INTCTRL = config.SPLIT.INTCTRL.LCMP2 << TCA_SPLIT_LCMP2_bp
									| config.SPLIT.INTCTRL.LCMP1 << TCA_SPLIT_LCMP1_bp
									| config.SPLIT.INTCTRL.LCMP0 << TCA_SPLIT_LCMP0_bp
									| config.SPLIT.INTCTRL.HUNF << TCA_SPLIT_HUNF_bp
									| config.SPLIT.INTCTRL.LUNF << TCA_SPLIT_LUNF_bp;
	} else {
		config.tca->SINGLE.INTCTRL = config.SINGLE.INTCTRL.CMP2 << TCA_SINGLE_CMP2_bp
									| config.SINGLE.INTCTRL.CMP1 << TCA_SINGLE_CMP1_bp
									| config.SINGLE.INTCTRL.CMP0 << TCA_SINGLE_CMP0_bp
									| config.SINGLE.INTCTRL.OVF << TCA_SINGLE_OVF_bp;
	}
}

/*
	void resetTcaINTFLAGS_CMP
	Reset the given CMP INTFLAG for the passed config settings
	
	config - TCA_CONFIG object containing the settings for TCA
	CMP_NUM - Which CMP INTFLAG to reset (0, 1, or 2)
*/
void resetTcaINTFLAGS_CMP(TCA_CONFIG config, uint8_t CMP_NUM) {
	if (config.split_mode) {
		switch(CMP_NUM) {
			case 0:
				config.tca->SPLIT.INTFLAGS = 1 << TCA_SPLIT_LCMP0_bp;
				break;
			case 1:
				config.tca->SPLIT.INTFLAGS = 1 << TCA_SPLIT_LCMP1_bp;
				break;
			case 2:
				config.tca->SPLIT.INTFLAGS = 1 << TCA_SPLIT_LCMP2_bp;
				break;
			default:
				break;
		}
	} else {
		switch(CMP_NUM) {
			case 0:
				config.tca->SINGLE.INTFLAGS = 1 << TCA_SINGLE_CMP0_bp;
				break;
			case 1:
				config.tca->SINGLE.INTFLAGS = 1 << TCA_SINGLE_CMP1_bp;
				break;
			case 2:
				config.tca->SINGLE.INTFLAGS = 1 << TCA_SINGLE_CMP2_bp;
				break;
			default:
				break;
		}
	}
}

/*
	void resetTcaINTFLAGS_OVF
	Reset the given OVF/UNF INTFLAG for the passed config settings
	
	config - TCA_CONFIG object containing the settings for TCA
	OVF_NUM - Which OVF/UNF INTFLAG to reset (0 or 1)
*/
void resetTcaINTFLAGS_OVF(TCA_CONFIG config, uint8_t OVF_NUM) {
	if (config.split_mode) {
		switch(OVF_NUM) {
			case 0:
				config.tca->SPLIT.INTFLAGS = 1 << TCA_SPLIT_LUNF_bp;
				break;
			case 1:
				config.tca->SPLIT.INTFLAGS = 1 << TCA_SPLIT_HUNF_bp;
				break;
			default:
				break;
		}
	} else {
		config.tca->SINGLE.INTFLAGS = 1 << TCA_SINGLE_OVF_bp;
	}
}

/*
	void resetTcaINTFLAGS
	Reset all TCA INTFLAGs
	
	config - TCA_CONFIG object containing the settings for TCA
*/
void resetTcaINTFLAGS(TCA_CONFIG config) {
	resetTcaINTFLAGS_OVF(config, 0);
	resetTcaINTFLAGS_OVF(config, 1);
		
	resetTcaINTFLAGS_CMP(config, 0);
	resetTcaINTFLAGS_CMP(config, 1);
	resetTcaINTFLAGS_CMP(config, 2);
}

/*
	void setTcaDBGCTRL
	Update TCA's DBGCTRL register with passed config settings
	
	config - TCA_CONFIG object containing settings for TCA
*/
void setTcaDBGCTRL(TCA_CONFIG config) {
	if(config.split_mode) {
		config.tca->SPLIT.DBGCTRL = config.SPLIT.DBGCTRL << TCA_SPLIT_DBGRUN_bp;
	} else {
		config.tca->SINGLE.DBGCTRL = config.SINGLE.DBGCTRL << TCA_SPLIT_DBGRUN_bp;
	}
}

/*
	void setTcaTEMP
	Update TCA's TEMP register with passed config settings
	
	config - TCA_CONFIG object containing settings for TCA
*/
void setTcaTEMP(TCA_CONFIG config) {
	if (!config.split_mode) {
		config.tca->SINGLE.TEMP = config.SINGLE.TEMP;
	}
}

/*
	void setTcaCNT
	Update TCA's CNT register with passed config settings
	
	config - TCA_CONFIG object containing settings for TCA
*/
void setTcaCNT(TCA_CONFIG config) {
	if(config.split_mode) {
		config.tca->SPLIT.LCNT = config.SPLIT.LCNT;
		config.tca->SPLIT.HCNT = config.SPLIT.HCNT;
	} else {
		config.tca->SINGLE.CNT = config.SINGLE.CNT;
	}
}

/*
	void setTcaPER
	Update TCA's PER register with passed config settings
	
	config - TCA_CONFIG object containing settings for TCA
*/
void setTcaPER(TCA_CONFIG config) {
	if(config.split_mode) {
		config.tca->SPLIT.LPER = config.SPLIT.LPER;
		config.tca->SPLIT.HPER = config.SPLIT.HPER;
	} else {
		config.tca->SINGLE.PER = config.SINGLE.PER;
	}
}

/*
	void setTcaCMP0
	Update TCA's CMP0 register with passed config settings
	
	config - TCA_CONFIG object containing settings for TCA
*/
void setTcaCMP0(TCA_CONFIG config) {
	if(config.split_mode) {
		config.tca->SPLIT.LCMP0 = config.SPLIT.LCMP0;
		config.tca->SPLIT.HCMP0 = config.SPLIT.HCMP0;
	} else {
		config.tca->SINGLE.CMP0 = config.SINGLE.CMP0;
	}
}

/*
	void setTcaCMP1
	Update TCA's CMP1 register with passed config settings
	
	config - TCA_CONFIG object containing settings for TCA
*/
void setTcaCMP1(TCA_CONFIG config) {
	if(config.split_mode) {
		config.tca->SPLIT.LCMP1 = config.SPLIT.LCMP1;
		config.tca->SPLIT.HCMP1 = config.SPLIT.HCMP1;
		} else {
		config.tca->SINGLE.CMP1 = config.SINGLE.CMP1;
	}
}

/*
	void setTcaCMP2
	Update TCA's CMP2 register with passed config settings
	
	config - TCA_CONFIG object containing settings for TCA
*/
void setTcaCMP2(TCA_CONFIG config) {
	if(config.split_mode) {
		config.tca->SPLIT.LCMP2 = config.SPLIT.LCMP2;
		config.tca->SPLIT.HCMP2 = config.SPLIT.HCMP2;
		} else {
		config.tca->SINGLE.CMP2 = config.SINGLE.CMP2;
	}
}

/*
	void setTcaPERBUF
	Update TCA's PERBUF register with passed config settings
	
	config - TCA_CONFIG object containing settings for TCA
*/
void setTcaPERBUF(TCA_CONFIG config) {
	if(!config.split_mode) {
		config.tca->SINGLE.PERBUF = config.SINGLE.PERBUF;
	}
}

/*
	void setTcaPERBUFH
	Update TCA's PERBUFH register with passed config settings
	
	config - TCA_CONFIG object containing settings for TCA
*/
void setTcaPERBUFH(TCA_CONFIG config) {
	if(!config.split_mode) {
		config.tca->SINGLE.PERBUFH = config.SINGLE.PERBUFH;
	}
}

/*
	void setTcaCMP0BUF
	Update TCA's CMP0BUF register with passed config settings
	
	config - TCA_CONFIG object containing settings for TCA
*/
void setTcaCMP0BUF(TCA_CONFIG config) {
	if(!config.split_mode) {
		config.tca->SINGLE.CMP0BUF = config.SINGLE.CMP0nBUF;
	}
}

/*
	void setTcaCMP1BUF
	Update TCA's CMP1BUF register with passed config settings
	
	config - TCA_CONFIG object containing settings for TCA
*/
void setTcaCMP1BUF(TCA_CONFIG config) {
	if(!config.split_mode) {
		config.tca->SINGLE.CMP1BUF = config.SINGLE.CMP1nBUF;
	}
}

/*
	void setTcaCMP2BUF
	Update TCA's CMP2BUF register with passed config settings
	
	config - TCA_CONFIG object containing settings for TCA
*/
void setTcaCMP2BUF(TCA_CONFIG config) {
	if(!config.split_mode) {
		config.tca->SINGLE.CMP2BUF = config.SINGLE.CMP2nBUF;
	}
}

/*
	void tcaSetup
	Attach the passed tca timer to the passed tcb config object and enable/disable split mode
	
	tca - Pointer to a TCB_t timer object to attach to a config
	tca_config - TCB_CONFIG object to attach the passed tcb timer to
	split_mode - boolean to enable/disable split mode
*/
void instantiateTCA(TCA_t* tca, TCA_CONFIG* tca_config, bool split_mode) {
	if(split_mode) enableTcaSplitMode(*tca_config, split_mode);
	tca_config->tca = tca;
}

/*
	void setWaveformTopTCA
	Set waveform TOP compare value
	
	config - pointer to TCA_CONFIG object
	CMP - compare value
*/
void setWaveformTopTCA(TCA_CONFIG* config, uint16_t CMP) {
	switch(config->SINGLE.CTRLB.WGMODE) {
		case TCA_SINGLE_WGMODE_FRQ_gc:
			config->SINGLE.CMP0 = CMP;
			config->SINGLE.CMP1 = CMP;
			config->SINGLE.CMP2 = CMP;
			setTcaCMP0(*config);
			setTcaCMP1(*config);
			setTcaCMP2(*config);
			break;
		default:
			config->SINGLE.PER = CMP;
			setTcaPER(*config);
			break;
	}
}

/*
	void initializeWaveformTCA
	Setup the config object to be a waveform
	
	config - pointer to TCA_CONFIG settings object
	wgmode - Waveform generation mode
	CMP - TOP compare value
	outputPin - Pin object to output the waveform on
*/
void initializeWaveformTCA(TCA_CONFIG* config, TCA_SINGLE_WGMODE_t wgmode,  uint16_t CMP, PIN_OBJ outputPin) {
	switch(outputPin.pin) {
		case 0:
			config->SINGLE.CTRLB.CMP0EN = true;
			break;
		case 1:
			config->SINGLE.CTRLB.CMP1EN = true;
			break;
		case 2:
			config->SINGLE.CTRLB.CMP2EN = true;
			break;
		default:
			return;
	}
	// pin setup
	PORTMUX.TCAROUTEA = outputPin.port_enum;
	initializeOutputPin(outputPin, false, PORT_PULL_OFF);
	
	config->SINGLE.CTRLB.WGMODE = wgmode;
	config->SINGLE.EVCTRL.CNTEI = false;	
	setTcaCTRLB(*config);
	setTcaEVCTRL(*config);
	setWaveformTopTCA(config, CMP);
}

/*
	void enableWaveformIntTCA
	enable interrupt channel
	
	config - pointer to TCA_CONFIG settings object
	channel - Channel to enable interrupt for
		0 - channel 0
		1 - channel 1
		2 - channel 2
		3 - all channels
*/
void setWaveformIntTCA(TCA_CONFIG* config, uint8_t channel, bool enable) {
	switch(channel) {
		case 0:
			config->SINGLE.INTCTRL.CMP0 = enable;
			break;
		case 1:
			config->SINGLE.INTCTRL.CMP1 = enable;
			break;
		case 2:
			config->SINGLE.INTCTRL.CMP2 = enable;
			break;
		case 3:
			config->SINGLE.INTCTRL.CMP0 = enable;
			config->SINGLE.INTCTRL.CMP1 = enable;
			config->SINGLE.INTCTRL.CMP2 = enable;
			break;
		default:
			return;
	}
}

/*
	void startWaveformTCA
	Start the waveform and enable the passed interrupt channel
	
	config - pointer to TCA_CONFIG settings object
	channel - Channel to enable interrupt for
		0 - channel 0
		1 - channel 1
		2 - channel 2
		3 - all channels
*/
void startWaveformTCA(TCA_CONFIG* config, uint8_t channel) {
	config->SINGLE.CTRLA.ENABLE = true;
	setWaveformIntTCA(config, channel, true);
	setTcaCTRLA(*config);
	setTcaINTCTRL(*config);
}

/*
	void stopWaveformTCA
	Stop the waveform and disable all interrupt channels
	
	config - pointer to TCA_CONFIG settings object
*/
void stopWaveformTCA(TCA_CONFIG* config) {
	config->SINGLE.CTRLA.ENABLE = false;
	setWaveformIntTCA(config, 3, false);
	setTcaCTRLA(*config);
	setTcaINTCTRL(*config);
}

/*
	void updateTca
	Update all TCA registers with information in the passed config object
	
	tcb_config - TCB_CONFIG object containing related TCB settings
*/
void updateTca(TCA_CONFIG tca_config) {
	setTcaCTRLA(tca_config);
	setTcaCTRLB(tca_config);
	setTcaCTRLC(tca_config);
	setTcaCTRLD(tca_config);
	setTcaCTRLECLR(tca_config);
	setTcaCTRLESET(tca_config);
	setTcaCTRLFCLR(tca_config);
	setTcaCTRLFSET(tca_config);
	setTcaEVCTRL(tca_config);
	setTcaINTCTRL(tca_config);
	setTcaDBGCTRL(tca_config);
	setTcaTEMP(tca_config);
	setTcaPER(tca_config);
	setTcaCMP0(tca_config);
	setTcaCMP1(tca_config);
	setTcaCMP2(tca_config);
	setTcaPERBUF(tca_config);
	setTcaPERBUFH(tca_config);
	setTcaCMP0BUF(tca_config);
	setTcaCMP1BUF(tca_config);
	setTcaCMP2BUF(tca_config);
}

//////////////////////////////////////////////////////////////////////////
// Periodic Interrupt
//////////////////////////////////////////////////////////////////////////

void initializePeriodicIntTCA(TCA_CONFIG* config, uint16_t timeout) {
	if (config->split_mode) return;
	config->SINGLE.INTCTRL.OVF = true;
	config->SINGLE.CTRLB.WGMODE = TCA_SINGLE_WGMODE_NORMAL_gc;
	config->SINGLE.EVCTRL.CNTEI = 0;
	config->SINGLE.PER = timeout;
	updateTca(*config);
}

void startPeriodicTCA(TCA_CONFIG* config) {
	if(config->SINGLE.CTRLB.WGMODE != TCA_SINGLE_WGMODE_NORMAL_gc) return;
	if(config->split_mode) return;
	config->SINGLE.CTRLA.ENABLE = true;
	config->SINGLE.CNT = 0;
	setTcaCNT(*config);
	setTcaCTRLA(*config);
	return;
}

void stopPeriodicTCA(TCA_CONFIG* config) {
	if (config->split_mode) return;
	config->SINGLE.CTRLA.ENABLE = false;
	resetTcaINTFLAGS_OVF(*config, 0);
	setTcaCTRLA(*config);
	return;
}