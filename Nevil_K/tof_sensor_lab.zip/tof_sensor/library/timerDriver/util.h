/*
 * util.h
 *
 * Created: 10/27/2023 12:55:37 PM
 *  Author: BenSchnuck
 */ 

#ifndef TIMER_UTIL_H_
#define TIMER_UTIL_H_

#include <avr/io.h>
#include <stdbool.h>
#include <stdint.h>
#include "gpioDriver.h"



#endif /* TIMER_UTIL_H_ */