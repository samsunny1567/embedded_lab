/*
 * tcbDriver.c
 *
 * Created: 10/27/2023 12:56:24 PM
 *  Author: BenSchnuck
 */ 

#include "util.h"
#include "tcbDriver.h"


/*
	void setTcbCTRLA
	Update TCB's CTRLA register with the passed config settings
	
	config - TCB_CONFIG settings object
*/
void setTcbCTRLA(TCB_CONFIG config) {
	config.tcb->CTRLA = config.CTRLA.CLKSEL << TCB_CLKSEL_gp
				| config.CTRLA.ENABLE << TCB_ENABLE_bp
				| config.CTRLA.RUNSTDBY << TCB_RUNSTDBY_bp
				| config.CTRLA.SYNCUPD << TCB_SYNCUPD_bp;
}

/*
	void setTcbCTRLB
	Update TCB's CTRLB register with the passed config settings
	
	config - TCB_CONFIG settings object
*/
void setTcbCTRLB(TCB_CONFIG config) {
	config.tcb->CTRLB = config.CTRLB.CNTMODE << TCB_CNTMODE_gp
				| config.CTRLB.ASYNC << TCB_ASYNC_bp
				| config.CTRLB.CCMPINIT << TCB_CCMPINIT_bp
				| config.CTRLB.CCPMEN << TCB_CCMPEN_bp;
}

/*
	void setTcbEVCTRL
	Update TCB's EVCTRL register with the passed config settings
	
	config - TCB_CONFIG settings object
*/
void setTcbEVCTRL(TCB_CONFIG config) {
	config.tcb->EVCTRL = config.EVCTRL.CAPTEI << TCB_CAPTEI_bp
					| config.EVCTRL.EDGE << TCB_EDGE_bp
					| config.EVCTRL.FILTER << TCB_FILTER_bp;
}

/*
	void setTcbINTCTRL
	Update TCB's INTCTRL register with the passed config settings
	
	config - TCB_CONFIG settings object
*/
void setTcbINTCTRL(TCB_CONFIG config) {
	config.tcb->INTCTRL = config.INTCTRL << TCB_CAPT_bp;
}

/*
	bool setTcbINTFLAGS
	Get TCB's INTFLAGS register
	
	config - TCB_CONFIG settings object
*/
bool getTcbINTFLAGS(TCB_CONFIG config) {
	return config.tcb->INTFLAGS;
}

/*
	void resetTcbINTFLAGS
	Reset INTFLAGS
	
	config - TCB_CONFIG settings object
*/
void resetTcbINTFLAGS(TCB_CONFIG config) {
	config.tcb->INTFLAGS = 1 << TCB_CAPT_bp;
}

/*
	bool setTcbSTATUS
	Get TCB's STATUS register
	
	config - TCB_CONFIG settings object
*/
bool getTcbSTATUS(TCB_CONFIG config) {
	return config.tcb->STATUS;
}

/*
	void setTcbDBGCTRL
	Update TCB's DBGCTRL register with the passed config settings
	
	config - TCB_CONFIG settings object
*/
void setTcbDBGCTRL(TCB_CONFIG config) {
	config.tcb->DBGCTRL = config.DBGCTRL;
}

/*
	void setTcbTEMP
	Update TCB's TEMP register with the passed config settings
	
	config - TCB_CONFIG settings object
*/
void setTcbTEMP(TCB_CONFIG config) {
	config.tcb->TEMP = config.TEMP;
}

/*
	uint16_t setTcbCNT
	Get TCB's CNT register
	
	config - TCB_CONFIG settings object
*/
uint16_t getTcbCNT(TCB_CONFIG config) {
	return config.tcb->CNT;
}

/*
	void setTcbCNT
	Update TCB's CNT register with the passed config settings
	
	config - TCB_CONFIG settings object
*/
void setTcbCNT(TCB_CONFIG config, uint16_t in_cnt) {
	config.tcb->CNT = in_cnt;
}

/*
	void setTcbCCMP
	Update TCB's CCMP register with the passed config settings
	
	config - TCB_CONFIG settings object
*/
void setTcbCCMP(TCB_CONFIG config) {
	config.tcb->CCMP = config.CCMP;
}

/*
	uint16_t setTcbCCMP
	Get TCB's CCMP register
	
	config - TCB_CONFIG settings object
*/
uint16_t getTcbCCMP(TCB_CONFIG config) {
	return config.tcb->CCMP;
}

/*
	void updateTcb
	Update all TCB registers with information in the passed config object
	
	tcb_config - TCB_CONFIG object containing related TCB settings
*/
void updateTcb(TCB_CONFIG tcb_config) {
	setTcbCTRLA(tcb_config);
	setTcbCTRLB(tcb_config);
	setTcbEVCTRL(tcb_config);
	setTcbINTCTRL(tcb_config);
	setTcbDBGCTRL(tcb_config);
	setTcbTEMP(tcb_config);
	setTcbCCMP(tcb_config);
}

/*
	void instantiateTCB
	Attach tcb pointer to config object
	
	config - pointer to TCB_CONFIG object to attach tcb to
	tcb - pointer to TCB object for the TCB_CONFIG object to use
*/
void instantiateTCB(TCB_CONFIG* config, TCB_t* tcb, TCB_CLKSEL_t clksel) {
	config->tcb = tcb;
	config->CTRLA.CLKSEL = clksel;
	config->CTRLA.ENABLE = true;
	updateTcb(*config);
}

//////////////////////////////////////////////////////////////////////////
// Periodic Interrupt
//////////////////////////////////////////////////////////////////////////
/*
	void initializePeriodicIntTCB
	Initialize a config object to be used as a Periodic Interrupt timer
	
	config - pointer to TCB_CONFIG object
	timeout - what value of CNT should the interrupt fire
*/
void initializePeriodicIntTCB(TCB_CONFIG* config, uint16_t timeout) {
	config->CTRLB.CNTMODE = TCB_CNTMODE_INT_gc;
	config->CCMP = timeout;
	config->CTRLA.ENABLE = false;
	updateTcb(*config);
}

/*
	void startPeriodicTCB
	Start the periodic TCB timer, enable the interrupt, reset CNT
	
	config - pointer to TCB_CONFIG object
*/
void startPeriodicTCB(TCB_CONFIG* config) {
	if(config->CTRLB.CNTMODE != TCB_CNTMODE_INT_gc) return;
	
	config->CTRLA.ENABLE = true;;
	config->INTCTRL = true;
	setTcbCNT(*config, 0);
	setTcbINTCTRL(*config);
	setTcbCTRLA(*config);
}

/*
	void stopPeriodicTCB
	Stop the periodic TCB timer, disable the interrupt
	
	config - pointer to TCB_CONFIG object to attach tcb to
*/
void stopPeriodicTCB(TCB_CONFIG* config) {
	config->CTRLA.ENABLE = false;
	config->INTCTRL = false;
	setTcbINTCTRL(*config);
	setTcbCTRLA(*config);
}

//////////////////////////////////////////////////////////////////////////
// 8-bit PWM
//////////////////////////////////////////////////////////////////////////
/*
	void initializePwmTCB
	Initialize a config object to be used as an 8-bit PWM
	
	config - pointer to TCB config object
	period - CCMPH value: number of cycles for which the output will be driven high
	duty_cycle - CCMPL value: period of the output pulse
*/
void initializePwmTCB(TCB_CONFIG* config, uint8_t period, uint8_t duty_cycle) {
	config->CCMP = 0x0000;
	config->CCMP = period;
	config->CCMP = config->CCMP << 8;
	config->CCMP |= duty_cycle;
	config->CTRLA.ENABLE = false;
	config->CTRLB.CNTMODE = TCB_CNTMODE_PWM8_gc;
	updateTcb(*config);
}

/*
	void startPwmTCB
	Start the PWM, enable the interrupt
	
	config - pointer to TCB_CONFIG object to attach tcb to
*/
void startPwmTCB(TCB_CONFIG* config, bool reset) {
	if(config->CTRLB.CNTMODE != TCB_CNTMODE_PWM8_gc) return;
	
	config->CTRLA.ENABLE = true;
	config->INTCTRL = true;
	if (reset) config->tcb->CNT = 0;
	setTcbINTCTRL(*config);
	setTcbCTRLA(*config);
}

/*
	void stopPwmTCB
	Stop the PWM, disable the interrupt
	
	config - pointer to TCB_CONFIG object to attach tcb to
*/
void stopPwmTCB(TCB_CONFIG* config) {
	config->CTRLA.ENABLE = false;
	config->INTCTRL = false;
	setTcbCTRLA(*config);
	setTcbINTCTRL(*config);
}