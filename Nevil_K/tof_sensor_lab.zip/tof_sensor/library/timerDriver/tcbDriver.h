/*
 * library.h
 *
 * Created: 10/16/2023 2:03:29 PM
 *  Author: BenSchnuck
 */ 


#ifndef LIBRARY_H_
#define LIBRARY_H_

/*
	Config object for CTRLA register of TCB
*/
typedef struct {
	bool RUNSTDBY;
	bool SYNCUPD;
	TCB_CLKSEL_t CLKSEL;
	bool ENABLE;
}TCB_CTRLA_CONFIG;

/*
	Config object for CTRLB register of TCB
*/
typedef struct {
	bool ASYNC;
	bool CCMPINIT;
	bool CCPMEN;
	TCB_CNTMODE_t CNTMODE;	
}TCB_CTRLB_CONFIG;

/*
	Config object for EVCTRL register of TCB
*/
typedef struct {
	bool FILTER;
	bool EDGE;
	bool CAPTEI;	
}TCB_EVCTRL_CONFIG;

/*
	Config object for TCB
*/
typedef struct {
	TCB_t* tcb;
	TCB_CTRLA_CONFIG CTRLA;
	TCB_CTRLB_CONFIG CTRLB;
	TCB_EVCTRL_CONFIG EVCTRL;
	bool INTCTRL;
	
	bool DBGCTRL;
	uint8_t TEMP;
	uint16_t CCMP;
}TCB_CONFIG;

void setTcbCTRLA(TCB_CONFIG config);
void setTcbCTRLB(TCB_CONFIG config);
void setTcbEVCTRL(TCB_CONFIG config);
void setTcbINTCTRL(TCB_CONFIG config);
bool getTcbINTFLAGS(TCB_CONFIG config);
void resetTcbINTFLAGS(TCB_CONFIG config);
bool getTcbSTATUS(TCB_CONFIG config);
void setTcbDBGCTRL(TCB_CONFIG config);
void setTcbTEMP(TCB_CONFIG config);
uint16_t getTcbCNT(TCB_CONFIG config);
void setTcbCNT(TCB_CONFIG config, uint16_t in_cnt);
void setTcbCCMP(TCB_CONFIG config);
uint16_t getTcbCCMP(TCB_CONFIG config);

void instantiateTCB(TCB_CONFIG* config, TCB_t* tcb, TCB_CLKSEL_t clksel);

void initializePeriodicIntTCB(TCB_CONFIG* config, uint16_t timeout);
void startPeriodicTCB(TCB_CONFIG* config);
void stopPeriodicTCB(TCB_CONFIG* config);

void initializePwmTCB(TCB_CONFIG* config, uint8_t period, uint8_t duty_cycle);
void startPwmTCB(TCB_CONFIG* config, bool reset);
void stopPwmTCB(TCB_CONFIG* config);

void updateTcb(TCB_CONFIG tcb_config);

#endif /* LIBRARY_H_ */