/*
 * eepromDriver.c
 *
 * Created: 12/21/2023 3:40:58 PM
 *  Author: BenSchnuck
 */ 

#include "eepromDriver.h"
#include "nvmDriver.h"

void eepromWait()
{
	while (FLASH_is_eeprom_ready()); 
	return;
}
/*
	Use this function or hard define eeprom reg as
	EepromRegister EE_REG_EXAMPLE =		{.address= 0x00, .length=1};
*/
void instantiate_eeprom_reg(EepromRegister* reg, uint8_t address, uint8_t length) {
	reg->address = address;
	reg->length = length;
	return;
}

/*
	uint8_t write_eeprom
	Write to the eeprom
	
	reg - Pointer to EepromRegister object to write to
	data - Pointer to uint8_t (can be array) of data to write
	dataLength - Length of data to write
	
*/
uint8_t write_eeprom(EepromRegister * reg, uint8_t *data, uint8_t dataLength, uint8_t padChar)
{

	uint8_t tmpData[20];
	uint8_t index=0;
	uint8_t padLength;
	if (dataLength > reg->length)
	return ERROR_ATMEGA_EEPROM_BASE + ERROR_ATMEGA_EEPROM_WRITE;
	else
	padLength = dataLength - reg->length;
	
	if (dataLength == 1)
	{
		FLASH_write_eeprom_byte(reg->address,(*data));
		eepromWait();
		tmpData[0] = FLASH_read_eeprom_byte(reg->address);
	}
	if (dataLength > 1)
	{
		FLASH_write_eeprom_block(reg->address,data,dataLength);
		if ((padLength > 0) & (padChar != 0xFF))
		{
			for (index=dataLength-1; index<reg->length; index++ )
			FLASH_write_eeprom_byte(reg->address+index,padChar);
		}
		eepromWait();
		FLASH_read_eeprom_block(reg->address,tmpData,dataLength);
	}
	for(index=0; index < dataLength; index++)
	{
		if (data[index] != tmpData[index++])
		return ERROR_ATMEGA_EEPROM_BASE + ERROR_ATMEGA_EEPROM_WRITE;
	}
	return ERROR_ATMEGA_EEPROM_NONE;
	
}

/*
	uint8_t read_eeprom
	Read from the eeprom
	
	reg - Pointer to EepromRegister object to read from
	data - Pointer to uint8_t (can be array) of data to store read data
*/
uint8_t read_eeprom(EepromRegister * reg, uint8_t *data)
{
	eepromWait();
	if (reg->length == 1)
	data[0] = FLASH_read_eeprom_byte(reg->address);
	if (reg->length > 1)
	FLASH_read_eeprom_block(reg->address,data,reg->length);
	return ERROR_ATMEGA_EEPROM_NONE;
}
