/*
 * usartSlave.c
 *
 * Created: 12/23/2023 12:17:48 PM
 * Author : PramodVariyam
 */ 
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <avr/io.h>
#include "gpioDriver.h"
#include "fullDuplexUsartDriver.h"
#include "usartSlave.h"

SlaveUartData SLAVE_DATA;

void slave_uart_initialize(USART_CONFIG* thisUart)
{
	SLAVE_DATA.uart_config = thisUart;
	SLAVE_DATA.state = UART_SLAVE_IDLE;
	SLAVE_DATA.num_bytes_received = 0;
}

void slave_uart_add_command(uint8_t cmd_index, uint8_t num_cmd_params, uint8_t num_resp_params, process_cmd_cb_t cb_fn)
{
	SLAVE_DATA.commands[cmd_index].actions_function = cb_fn;
	SLAVE_DATA.commands[cmd_index].num_cmd_params = num_cmd_params;
	SLAVE_DATA.commands[cmd_index].num_resp_params = num_resp_params;
}

void process_uart_command()
{
	SlaveCommand* this_cmd=NULL;
	switch(SLAVE_DATA.state)
	{
		case(UART_SLAVE_IDLE):
		if (SLAVE_DATA.num_bytes_received > 0)
		{
			USART_read(SLAVE_DATA.uart_config, &(SLAVE_DATA.command_index));
			this_cmd = &(SLAVE_DATA.commands[SLAVE_DATA.command_index]);
			SLAVE_DATA.state = UART_SLAVE_RECEIVING;
		}
		break;
		case(UART_SLAVE_RECEIVING):
		if (SLAVE_DATA.num_bytes_received == this_cmd->num_cmd_params + 1) // First byte is command
		{
			USART_read_n(SLAVE_DATA.uart_config, SLAVE_DATA.parameter,this_cmd->num_cmd_params);
			SLAVE_DATA.state = UART_SLAVE_PROCESSING;
			SLAVE_DATA.num_bytes_received = 0;
		}
		break;
		case(UART_SLAVE_PROCESSING):
		if (this_cmd->actions_function != NULL)
		(*this_cmd->actions_function)();
		USART_write_n(SLAVE_DATA.uart_config,SLAVE_DATA.response, this_cmd->num_resp_params);
		SLAVE_DATA.state = UART_SLAVE_IDLE;
		break;
	}
}



// ISR for RX
void slave_uart_default_rx_isr()
{
	USART_default_rx_isr(SLAVE_DATA.uart_config);
	SLAVE_DATA.num_bytes_received++;
	return;
}

// ISR for TX
void slave_uart_default_tx_isr()
{
	USART_default_tx_isr(SLAVE_DATA.uart_config);
	return;
}
