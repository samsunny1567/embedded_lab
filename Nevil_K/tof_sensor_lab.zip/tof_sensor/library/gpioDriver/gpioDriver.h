/*
 * port.h
 *
 * Created: 10/16/2023 1:18:49 PM
 *  Author: Ben Schnuck
 */ 


#ifndef GPIO_DRIVER_H_
#define GPIO_DRIVER_H_

/*
	Helper enum for referencing the different VPORTs
*/
typedef enum {
	PIN_PORTA=0,
	PIN_PORTB=1,
	PIN_PORTC=2,
	PIN_PORTD=3,
	PIN_PORTE=4,
	PIN_PORTF=5
} PIN_PORTS;

/*
	PIN_OBJ
	This object represents a pin on the chip. All functions in this driver require
	the use of PIN_OBJs
	
	port - Pointer to a VPORT object, the port that the pin belongs to.
	pin - The pin number of the port that the pin belongs to.	
*/
typedef struct {
	VPORT_t* port;
	PIN_PORTS port_enum;
	uint8_t pin;
} PIN_OBJ;

/*
	port_dir
	Pin direction enum
*/
enum port_dir {
	PORT_DIR_IN,
	PORT_DIR_OUT,
	PORT_DIR_OFF,
};

/*
	port_pull_mode
	Enum for port pull modes.
*/
enum port_pull_mode {
	PORT_PULL_OFF,
	PORT_PULL_UP,
};

// Function Declarations
bool instantiatePin(PIN_OBJ* pin_obj, PIN_PORTS port_selection, uint8_t pin_number);
uint8_t initializeOutputPin(PIN_OBJ pin_obj, bool initialLevel, const enum port_pull_mode pull_mode);
uint8_t initializeInputPin(PIN_OBJ pin_obj, const enum port_pull_mode pull_mode);

void setPinDir(PIN_OBJ* pin, const enum port_dir dir);
void setPinLevel(PIN_OBJ* pin, const bool level);
void setPinPullMode(PIN_OBJ* pin, const enum port_pull_mode pull_mode);
void togglePinLevel(PIN_OBJ* pin);
bool getPinLevel(PIN_OBJ* pin);
void setPinIsc(PIN_OBJ* pin, const PORT_ISC_t isc);
void setPinInverted(PIN_OBJ* pin, const bool inverted);

#endif /* GPIO_DRIVER_H_ */