/*
 * gpioDriver.c
 *
 * Created: 10/19/2023 11:40:43 AM
 *  Author: BenSchnuck
 */ 

#include <avr/io.h>
#include <stdbool.h>
#include <stdint.h>
#include "gpioDriver.h"

int8_t* getPortPointer(PIN_OBJ* pin) {
	int8_t* port_ptr = 0;
	
	switch(pin->port_enum) {
		case PIN_PORTA:
		port_ptr = (int8_t*)(&PORTA) + 0x10 + pin->pin;
		break;
		case PIN_PORTB:
		port_ptr = (int8_t*)(&PORTB) + 0x10 + pin->pin;
		break;
		case PIN_PORTC:
		port_ptr = (int8_t*)(&PORTC) + 0x10 + pin->pin;
		break;
		case PIN_PORTD:
		port_ptr = (int8_t*)(&PORTD) + 0x10 + pin->pin;
		break;
		case PIN_PORTE:
		port_ptr = (int8_t*)(&PORTE) + 0x10 + pin->pin;
		break;
		case PIN_PORTF:
		port_ptr = (int8_t*)(&PORTF) + 0x10 + pin->pin;
		break;
	}
	
	return port_ptr;
}

/*
	void setPinDir
	Set the pin direction of a given pin
	
	pin - pin to set the direction of
	dir - direction to set the pin
*/
void setPinDir(PIN_OBJ* pin, const enum port_dir dir) {
	switch(dir) {
		case PORT_DIR_IN:
			pin->port->DIR &= ~(1 << pin->pin);
			break;
		case PORT_DIR_OUT:
			pin->port->DIR |= (1 << pin->pin);
			break;
		case PORT_DIR_OFF:
			*((uint8_t *)pin->port + 0x10 + pin->pin) |= 1 << PORT_PULLUPEN_bp;
			break;
		default:
			break;
	}
}

/*
	void setPinLevel
	Set the pin level of a given pin
	
	pin - pin to edit
	level - desired level of the passed pin. True - HIGH, False - LOW.
*/
void setPinLevel(PIN_OBJ* pin, const bool level) {
	if (level) {
		pin->port->OUT |= (1 << pin->pin);
	}
	else {
		pin->port->OUT &= ~(1 << pin->pin);
	}
}

/*
	void setPinPullMode
	Set the pull mode of a given pin
	
	pin - pin to edit
	pull_mode - desired pull mode of the passed pin. 
		PORT_PULL_OFF - No pull up
		PORT_PULL_UP - Enable pull up resistor on pin
*/
void setPinPullMode(PIN_OBJ* pin, const enum port_pull_mode pull_mode) {
	int8_t* port_ptr = getPortPointer(pin);
	
	if(pull_mode == PORT_PULL_UP) {
		*port_ptr |= PORT_PULLUPEN_bm;
	} else if (pull_mode == PORT_PULL_OFF) {
		*port_ptr &= ~PORT_PULLUPEN_bm;
	}
}

/*
	void togglePinLevel
	Toggle the current level of the given pin
	
	pin - pin to edit
*/
void togglePinLevel(PIN_OBJ* pin) {
	pin->port->IN |= 1 << pin->pin;
}

/*
	bool getPinLevel
	Returns the current state of the given pin
	
	pin - pin to get level of
*/
bool getPinLevel(PIN_OBJ* pin) {
	return pin->port->IN & (1 << pin->pin);
}

/*
	void setPinIsc
	Set the ISC mode for the given pin
	
	pin - pin to edit
	isc - ISC mode for the pin
		PORT_ISC_INTDISABLE_gc - Interrupt disabled by input buffer enabled
		PORT_ISC_BOTHEDGES_gc - Interrupt on both edges
		PORT_ISC_RISING_gc - Interrupt on rising edge
		PORT_ISC_FALLING_gc - Interrupt on falling edge
		PORT_ISC_INPUT_DISABLE_gc - Digital input buffer disabled
		PORT_ISC_LEVEL_gc - Sense low level
*/
void setPinIsc(PIN_OBJ* pin, const PORT_ISC_t isc) {
	int8_t* port_ptr = getPortPointer(pin);
	
	*port_ptr = (*port_ptr & ~PORT_ISC_gm) | isc;
}
/*
	void setPinInverted
	Invert a given pin's input
	
	pin - pin to edit
	inverted - desired invert mode
		true - Invert input
		false - noninverted input
*/
void setPinInverted(PIN_OBJ* pin, const bool inverted) {
	int8_t* port_ptr = getPortPointer(pin);
	
	if(inverted) {
		*port_ptr |= PORT_INVEN_bm;
	} else {
		*port_ptr &= ~PORT_INVEN_bm;
	}
}

/*
	bool instantiatePin
	Populate a pin object with given settings
	
	return bool - 
		true - Error encountered while setting up pin object, pin obj not created
		false - pin created without issue
	
	pin_obj - pointer to pin object to populate
	port_selection - Port that the pin belongs to
		PIN_PORTA - VPORTA
		PIN_PORTB - VPORTB
		PIN_PORTC - VPORTC
		PIN_PORTD - VPORTD
		PIN_PORTE - VPORTE
		PIN_PORTF - VPORTF
	pin_number - pin number for the pin
*/
bool instantiatePin(PIN_OBJ* pin_obj, PIN_PORTS port_selection, uint8_t pin_number) {
	if (pin_number > 7) return true;
	pin_obj->pin = pin_number;
	switch(port_selection) {
		case PIN_PORTA:
		pin_obj->port = &VPORTA;
		break;
		case PIN_PORTB:
		pin_obj->port = &VPORTB;
		break;
		case PIN_PORTC:
		pin_obj->port = &VPORTC;
		break;
		case PIN_PORTD:
		pin_obj->port = &VPORTD;
		break;
		case PIN_PORTE:
		pin_obj->port = &VPORTE;
		break;
		case PIN_PORTF:
		pin_obj->port = &VPORTF;
		break;
	}
	pin_obj->port_enum = port_selection;
	return false;
}

uint8_t initializeOutputPin(PIN_OBJ pin_obj, bool initialLevel, const enum port_pull_mode pull_mode) {
	setPinLevel(&pin_obj, initialLevel);
	setPinDir(&pin_obj, PORT_DIR_OUT);
	setPinPullMode(&pin_obj, pull_mode);
	return 1;
}

uint8_t initializeInputPin(PIN_OBJ pin_obj, const enum port_pull_mode pull_mode) {
	setPinLevel(&pin_obj, false);
	setPinDir(&pin_obj, PORT_DIR_IN);
	setPinPullMode(&pin_obj, pull_mode);
	setPinInverted(&pin_obj, false);
	return 1;
}