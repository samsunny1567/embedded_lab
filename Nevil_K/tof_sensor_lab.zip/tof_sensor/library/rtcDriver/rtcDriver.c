/*
 * rtc.c
 *
 * Created: 10/18/2023 3:09:00 PM
 *  Author: BenSchnuck
 */ 

#include <avr/io.h>
#include <stdbool.h>
#include <stdint.h>
#include "rtcDriver.h"


/*
	void setRtcCTRLA
	Update RTC's CTRLA register with passed config settings
	
	config - RTC_CONFIG settings object
*/
void setRtcCTRLA(RTC_CONFIG config) {
	config.rtc->CTRLA = config.CTRLA.PRESCALER
				| config.CTRLA.RTCEN << RTC_RTCEN_bp
				| config.CTRLA.RUNSTDBY << RTC_RUNSTDBY_bp
				| config.CTRLA.CORREN << RTC_CORREN_bp;
}

/*
	void setRtcPITCTRLA
	Update RTC's PITCTRLA register with passed config settings
	
	config - RTC_CONFIG settings object
*/
void setRtcPITCTRLA(RTC_CONFIG config) {
	config.rtc->PITCTRLA = config.PITCTRLA.PERIOD
				| config.PITCTRLA.PITEN << RTC_PITEN_bp;
}

/*
	void setRtcINTCTRL
	Update RTC's INTCTRL register with passed config settings
	
	config - RTC_CONFIG settings object
*/
void setRtcINTCTRL(RTC_CONFIG config) {
	config.rtc->INTCTRL = config.INTCTRL.CMP << RTC_CMP_bp
					| config.INTCTRL.OVF << RTC_OVF_bp;
}

/*
	void setRtcDBGCTRL
	Update RTC's DBGCTRL register with passed config settings
	
	config - RTC_CONFIG settings object
*/
void setRtcDBGCTRL(RTC_CONFIG config) {
	config.rtc->DBGCTRL = config.DBGRUN << RTC_DBGRUN_bp;
}

/*
	void setRtcCMP
	Update RTC's CMP register with passed config settings
	
	config - RTC_CONFIG settings object
*/
void setRtcCMP(RTC_CONFIG config) {
	config.rtc->CMP = config.CMP;
}

/*
	uint16_t getRtcCMP
	Get RTC's CMP register from passed config settings
	
	config - RTC_CONFIG settings object
*/
uint16_t getRtcCMP(RTC_CONFIG config) {
	return config.rtc->CMP;
}

/*
	void setRtcPITDBGCTRL
	Update RTC's PITDBGCTRL register with passed config settings
	
	config - RTC_CONFIG settings object
*/
void setRtcPITDBGCTRL(RTC_CONFIG config) {
	config.rtc->PITDBGCTRL = config.PITDBGCTRL << RTC_DBGRUN_bp;
}

/*
	void setRtcPITINTCTRL
	Update RTC's PITINTCTRL register with passed config settings
	
	config - RTC_CONFIG settings object
*/
void setRtcPITINTCTRL(RTC_CONFIG config) {
	config.rtc->PITINTCTRL = config.PITINTCTRL << RTC_PI_bp;
}

/*
	void setRtcCLKSEL
	Update RTC's CLKSEL register with passed config settings
	
	config - RTC_CONFIG settings object
*/
void setRtcCLKSEL(RTC_CONFIG config) {
	config.rtc->CLKSEL = config.CLKSEL;
}

/*
	void resetRtcINTFLAGS
	Reset the RTC's INTFLAGS
*/
void resetRtcINTFLAGS(RTC_CONFIG config) {
	config.rtc->INTFLAGS = RTC_CMP_bm | RTC_OVF_bm;
}


/*
	void instantiateDefaultRTC
	Function to set up passed config object with default values and initialize the
	RTC system based on that config object.
	
	config - pointer to RTC_CONFIG object to setup
*/
void instantiateRTC(RTC_CONFIG* config, RTC_t* rtc) {
	config->rtc = rtc;
	config->CTRLA.PRESCALER = RTC_PRESCALER_DIV1_gc;
	config->CTRLA.RTCEN = false;
	config->CTRLA.RUNSTDBY = false;
	
	config->PER = 0xFFFF;
	config->CMP = 0x0000;
	config->CLKSEL = RTC_CLKSEL_INT32K_gc;
	config->DBGRUN = true;
	
	config->INTCTRL.CMP = true;
	
	config->PITDBGCTRL = true;
}

/*
	void RTC_init
	Initialize RTC system based off passed RTC_CONFIG
	
	config - config object containing initialization settings
*/
void initializeRTC(RTC_CONFIG config) {
	while (config.rtc->STATUS > 0);
	
	config.state = TIMER_STOPPED;
	config.rtc->CNT = 0x0000;
	
	setRtcCMP(config);
	
	setRtcCLKSEL(config);
	
	setRtcDBGCTRL(config);
	
	setRtcINTCTRL(config);
				
	setRtcPITCTRLA(config);
				
	setRtcPITDBGCTRL(config);
	
	setRtcPITINTCTRL(config);
}

/*
	void rtcSetTimeout
	Set the RTC timeout value and apply it
	
	config - config object containing the settings for RTC
	time_out - timeout amount in cycles
*/
void rtcSetTimeout(RTC_CONFIG config, uint16_t time_out) {
	while(config.rtc->STATUS > 0);
	config.CMP = time_out;
	setRtcCMP(config);
}

/*
	void rtcStart
	Start the RTC timer based on a given timeout
	
	config - config object containing the settings for RTC
	time_out - timeout amount in cycles
*/
void rtcStart(RTC_CONFIG config, uint16_t time_out) {
	while (config.rtc->STATUS > 0);
	config.timeout = false;
	config.rtc->CNT = 0x0000;
	rtcSetTimeout(config, time_out);
	resetRtcINTFLAGS(config);
	config.CTRLA.RTCEN = true;
	setRtcCTRLA(config);
	config.state = TIMER_RUNNING;
}

/*
	void rtcStop
	Stop the RTC timer
	
	config - config object containing the settings for RTC
*/
void rtcStop(RTC_CONFIG config) {
	while (config.rtc->STATUS > 0);
	config.CTRLA.RTCEN = false;
	setRtcCTRLA(config);
	config.state = TIMER_STOPPED;
}

/*
	void rtcISR
	Default ISR function for the RTC
	
	config - config object containing the settings for RTC
*/
void defaultRtcISR(RTC_CONFIG config) {
	resetRtcINTFLAGS(config);
	
	config.timeout = true;
	
	rtcStop(config);
}

/*
	bool rtcTimeout
	Return if the RTC module has timed out
	
	config - config object containing the settings for RTC
*/
bool rtcTimeout(RTC_CONFIG config) {
	return config.timeout;
}