/*
 * rtc.h
 *
 * Created: 10/18/2023 3:08:51 PM
 *  Author: BenSchnuck
 */ 


#ifndef RTC_H_
#define RTC_H_

/*
	Config object for CTRLA register of RTC
*/
typedef struct{
	bool RUNSTDBY;
	RTC_PRESCALER_t PRESCALER;
	bool CORREN;
	bool RTCEN;
} RTC_CTRLA_CONFIG;

/*
	Config object for INTCTRL register of RTC
*/
typedef struct {
	bool CMP;
	bool OVF;
} RTC_INTCTRL_CONFIG;

/*
	Config object for PITCTRLA register of RTC
*/
typedef struct {
	bool PITEN;
	RTC_PERIOD_t PERIOD;
} RTC_PITCTRLA_CONFIG;

/*
	enum for RTC states
*/
typedef enum {
	TIMER_STOPPED,
	TIMER_RUNNING
} RTC_STATE;

/*
	Config object for RTC registers
*/
typedef struct {
	RTC_STATE state;
	RTC_t* rtc;
	bool timeout;
	
	RTC_CTRLA_CONFIG CTRLA;
	RTC_CLKSEL_t CLKSEL;
	uint16_t CMP;
	uint16_t PER;
	bool DBGRUN;
	RTC_INTCTRL_CONFIG INTCTRL;
	RTC_PITCTRLA_CONFIG PITCTRLA;
	bool PITDBGCTRL;
	bool PITINTCTRL;
} RTC_CONFIG;

// Function Declarations 
void setRtcCTRLA(RTC_CONFIG config);
void setRtcPITCTRLA(RTC_CONFIG config);
void setRtcINTCTRL(RTC_CONFIG config);
void setRtcDBGCTRL(RTC_CONFIG config);
void setRtcCMP(RTC_CONFIG config);
uint16_t getRtcCMP(RTC_CONFIG config);
void setRtcPITDBGCTRL(RTC_CONFIG config);
void setRtcPITINTCTRL(RTC_CONFIG config);
void setRtcCLKSEL(RTC_CONFIG config);
void resetRtcINTFLAGS(RTC_CONFIG config);

void instantiateRTC(RTC_CONFIG* config, RTC_t* rtc);
void initializeRTC(RTC_CONFIG config);
void rtcSetTimeout(RTC_CONFIG config, uint16_t time_out);
void rtcStart(RTC_CONFIG config, uint16_t time_out);
void rtcStop(RTC_CONFIG config);
void defaultRtcISR(RTC_CONFIG config);
bool rtcTimeout(RTC_CONFIG config);

#endif /* RTC_H_ */