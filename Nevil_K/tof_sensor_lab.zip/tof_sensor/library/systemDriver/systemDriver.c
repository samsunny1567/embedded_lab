/*
 * system.c
 *
 * Created: 10/23/2023 2:38:11 PM
 *  Author: BenSchnuck
 */ 

#include <avr/io.h>
#include "utils/ccp.h"
#include "utils/compiler.h"
#include "systemDriver.h"

void instantiateSystem(void) {
	SYSTEMCONFIG.clkCtrl.MCLKCTRLB.PEN = true;
	SYSTEMCONFIG.clkCtrl.MCLKCTRLB.PDIV = CLKCTRL_PDIV_6X_gc;
	SYSTEMCONFIG.clkCtrl.MCLKLOCK.LOCKEN = (FUSE.OSCCFG & 0x80) >> 7;
	
	SYSTEMCONFIG.bod.CTRLA.ACTIVE = (FUSE.BODCFG & 0x0C) >> 2;
	SYSTEMCONFIG.bod.CTRLA.SAMPFREQ = (FUSE.BODCFG & 0x10) >> 4;
	SYSTEMCONFIG.bod.CTRLA.SLEEP = (FUSE.BODCFG & 0x03) >> 0;
	SYSTEMCONFIG.bod.CTRLB.LVL = (FUSE.BODCFG & 0xE0) >> 5;
}

void mcu_init(void)
{
	/* Set all pins to low power mode */
	uint8_t i = 0;

	for (i = 0; i < 8; i++) {
		*((uint8_t *)&PORTA + 0x10 + i) |= 1 << PORT_PULLUPEN_bp;
	}

	for (i = 0; i < 8; i++) {
		*((uint8_t *)&PORTB + 0x10 + i) |= 1 << PORT_PULLUPEN_bp;
	}

	for (i = 0; i < 8; i++) {
		*((uint8_t *)&PORTC + 0x10 + i) |= 1 << PORT_PULLUPEN_bp;
	}

	for (i = 0; i < 8; i++) {
		*((uint8_t *)&PORTD + 0x10 + i) |= 1 << PORT_PULLUPEN_bp;
	}

	for (i = 0; i < 8; i++) {
		*((uint8_t *)&PORTE + 0x10 + i) |= 1 << PORT_PULLUPEN_bp;
	}

	for (i = 0; i < 8; i++) {
		*((uint8_t *)&PORTF + 0x10 + i) |= 1 << PORT_PULLUPEN_bp;
	}
}

int8_t BOD_init()
{
	ccp_write_io((void*)&(BOD.CTRLA), SYSTEMCONFIG.bod.CTRLA.ACTIVE << BOD_ACTIVE_gp
									| SYSTEMCONFIG.bod.CTRLA.SAMPFREQ << BOD_SAMPFREQ_bp
									| SYSTEMCONFIG.bod.CTRLA.SLEEP << BOD_SLEEP_gp);
	
	ccp_write_io((void*)&(BOD.CTRLB), SYSTEMCONFIG.bod.CTRLB.LVL << BOD_LVL_gp);

	BOD.INTCTRL = SYSTEMCONFIG.bod.INTCTRL.VLMIE << BOD_VLMIE_bp
			 | SYSTEMCONFIG.bod.INTCTRL.VLMCFG << BOD_VLMCFG_gp; 

	BOD.VLMCTRLA = SYSTEMCONFIG.bod.VLMLVL;

	return 0;
}

int8_t CPUINT_init()
{
	ccp_write_io((void*)&(CPUINT.CTRLA), SYSTEMCONFIG.cpuInt.CTRLA.CVT << CPUINT_CVT_bp
									 | SYSTEMCONFIG.cpuInt.CTRLA.IVSEL << CPUINT_IVSEL_bp
									 | SYSTEMCONFIG.cpuInt.CTRLA.LVL0RR << CPUINT_LVL0RR_bp);

	CPUINT.LVL0PRI = SYSTEMCONFIG.cpuInt.LVL0PRI << CPUINT_LVL0PRI_gp;

	CPUINT.LVL1VEC = SYSTEMCONFIG.cpuInt.LVL1VEC << CPUINT_LVL1VEC_gp; 

	return 0;
}

int8_t SLPCTRL_init()
{
	SLPCTRL.CTRLA = SYSTEMCONFIG.slpCtrl.CTRLA.SEN << SLPCTRL_SEN_bp 
				 | SYSTEMCONFIG.slpCtrl.CTRLA.SMODE << SLPCTRL_SMODE_gp;

	return 0;
}

void SLPCTRL_set_sleep_mode(SLPCTRL_SMODE_t setmode)
{
	SLPCTRL.CTRLA = (SLPCTRL.CTRLA & ~SLPCTRL_SMODE_gm) | (setmode & SLPCTRL_SMODE_gm);
}

void RSTCTRL_reset(void) {
	ccp_write_io((void *)&RSTCTRL.SWRR, 0x1);
}

uint8_t RSTCTRL_get_reset_cause(void)
{
	return RSTCTRL.RSTFR;
}

void RSTCTRL_clear_reset_cause(void)
{
	RSTCTRL.RSTFR
	= RSTCTRL_UPDIRF_bm | RSTCTRL_SWRF_bm | RSTCTRL_WDRF_bm | RSTCTRL_EXTRF_bm | RSTCTRL_BORF_bm | RSTCTRL_PORF_bm;
}

void RSTCTRL_reset_flag(RST_FLAGS flag) {
	switch(flag) {
		case RST_UPDIRF:
			RSTCTRL.RSTFR |= 1 << RSTCTRL_UPDIRF_bp;
			break;
		case RST_SWRF:
			RSTCTRL.RSTFR |= 1 << RSTCTRL_SWRF_bp;
			break;
		case RST_WDRF:
			RSTCTRL.RSTFR |= 1 << RSTCTRL_WDRF_bp;
			break;
		case RST_EXTRF:
			RSTCTRL.RSTFR |= 1 << RSTCTRL_EXTRF_bp;
			break;
		case RST_BORF:
			RSTCTRL.RSTFR |= 1 << RSTCTRL_BORF_bp;
			break;
		case RST_PORF:
			RSTCTRL.RSTFR |= 1 << RSTCTRL_PORF_bp;
			break;
	}
}