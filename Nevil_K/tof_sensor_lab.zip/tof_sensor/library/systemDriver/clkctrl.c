/*
 * clkctrl.c
 *
 * Created: 10/23/2023 2:14:22 PM
 *  Author: BenSchnuck
 */ 

#include "utils/clkctrl.h"
#include "utils/ccp.h"
#include "systemDriver.h"

void default_CLKCTRL_settings(void) {
	SYSTEMCONFIG.clkCtrl.MCLKCTRLB.PEN = true;
	SYSTEMCONFIG.clkCtrl.MCLKCTRLB.PDIV = CLKCTRL_PDIV_8X_gc;
	SYSTEMCONFIG.clkCtrl.MCLKCTRLA.CLKSEL = CLKCTRL_CLKSEL_OSC20M_gc;
}

int8_t CLKCTRL_init(void) {
	ccp_write_io((void*)&(CLKCTRL.OSC32KCTRLA), SYSTEMCONFIG.clkCtrl.OSC32KCTRLA.RUNSTDBY << CLKCTRL_RUNSTDBY_bp);

	ccp_write_io((void*)&(CLKCTRL.XOSC32KCTRLA),SYSTEMCONFIG.clkCtrl.XOSC32KCTRLA.CSUT << CLKCTRL_CSUT_gp
			 | SYSTEMCONFIG.clkCtrl.XOSC32KCTRLA.ENABLE << CLKCTRL_ENABLE_bp
			 | SYSTEMCONFIG.clkCtrl.XOSC32KCTRLA.RUNSTDBY << CLKCTRL_RUNSTDBY_bp
			 | SYSTEMCONFIG.clkCtrl.XOSC32KCTRLA.SEL << CLKCTRL_SEL_bp);

	ccp_write_io((void*)&(CLKCTRL.OSC20MCTRLA),SYSTEMCONFIG.clkCtrl.OSC20MCTRLA.RUNSTDBY << CLKCTRL_RUNSTDBY_bp);

	ccp_write_io((void *)&(CLKCTRL.MCLKCTRLB),
			(SYSTEMCONFIG.clkCtrl.MCLKCTRLB.PDIV
			| SYSTEMCONFIG.clkCtrl.MCLKCTRLB.PEN));

	ccp_write_io((void *)&(CLKCTRL.MCLKCTRLA),
			SYSTEMCONFIG.clkCtrl.MCLKCTRLA.CLKSEL 
			| SYSTEMCONFIG.clkCtrl.MCLKCTRLA.CLKOUT << CLKCTRL_CLKOUT_bp);

	/* wait for system oscillator changing to finish */
	while (CLKCTRL.MCLKSTATUS & CLKCTRL_SOSC_bm) {
	}

	ccp_write_io((void*)&(CLKCTRL.MCLKLOCK),SYSTEMCONFIG.clkCtrl.MCLKLOCK.LOCKEN << CLKCTRL_LOCKEN_bp);

	return 0;
}