/*
 * i2cMaster.h
 *
 * Created: 12/21/2023 10:26:23 AM
 *  Author: BenSchnuck
 */ 


#ifndef I2CMASTER_H_
#define I2CMASTER_H_

#include "util.h"
#include "i2c_types.h"
#include "twiDriver.h"

#define TWI_BAUD(CPU_CLK, F_SCL, T_RISE) ((((((float)CPU_CLK / (float)F_SCL)) - 10 - ((float)CPU_CLK * T_RISE / 1000000))) / 2)

void I2C_init_master(TWI_CONFIG* config);
i2c_error_t I2C_open_master(TWI_CONFIG* config, i2c_address_t address);

i2c_error_t I2C_close_master(TWI_CONFIG* config);

i2c_error_t I2C_master_operation(TWI_CONFIG* config, bool read);

i2c_error_t I2C_master_write(TWI_CONFIG* config); // to be depreciated

i2c_error_t I2C_master_read(TWI_CONFIG* config); // to be depreciated

void I2C_set_timeout(TWI_CONFIG* config, uint8_t to);

void I2C_set_baud_rate(TWI_CONFIG* config, uint32_t baud);

void I2C_set_buffer(void *buffer, size_t bufferSize);

// Event Callback functions.

void I2C_set_data_complete_callback(i2c_callback cb, void *p);

void I2C_set_write_collision_callback(i2c_callback cb, void *p);

void I2C_set_address_nack_callback(i2c_callback cb, void *p);

void I2C_set_data_nack_callback(i2c_callback cb, void *p);

void I2C_set_timeout_callback(i2c_callback cb, void *p);


#endif /* I2CMASTER_H_ */