/*
 * twiDriver.c
 *
 * Created: 10/23/2023 11:10:52 AM
 * Author : BenSchnuck
 */ 

#include <avr/io.h>
#include "util.h"
#include "i2cDriver.h"
#include "twiDriver.h"
#include "i2cMaster.h"

/*
	instantiateTWI
	
	Use this function to setup a twi config object
	
	config - pointer to TWI_CONFIG object to be initialize
	twi - pointer to a TWI object e.g. TWI0, TWI1, etc
	cpu_clk - Set cpu clk
	baud - baud rate
*/
void instantiateTWI(TWI_CONFIG* config, TWI_t* twi, float cpu_clk, float baud) {
	config->twi = twi;
	config->cpu_clk = cpu_clk;
	config->baud = baud;
	updateTwiRegisters(*config);
}

/*
	initializeI2C
	
	Use this function to setup a twi config object
	
	config - pointer to TWI_CONFIG object to be initialize
*/
void initializeI2cMaster(TWI_CONFIG* config) {
	
	I2C_init_master(config);
	
}

