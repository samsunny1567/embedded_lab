/*
 * i2cDriver.c
 *
 * Created: 10/23/2023 1:51:23 PM
 *  Author: BenSchnuck
 */ 

#include "util.h"
#include "i2cDriver.h"
#include "i2cMaster.h"

static i2c_operations_t I2C_wr1RegCompleteHandler(void *p)
{
	I2C_set_buffer(p, 1);
	I2C_set_data_complete_callback(NULL, NULL);
	return i2c_continue;
}

/*
	I2C_write1ByteRegister
	Write to a 1 Byte Register
	
	config - pointer to TWI_CONFIG object
	address - I2C address to write to
	reg - Register address to write to
	data - Byte to write
*/
i2c_error_t I2C_write1ByteRegister(TWI_CONFIG* config, i2c_address_t address, uint8_t reg, uint8_t data)
{
	/* timeout is used to get out of twim_release, when there is no device connected to the bus*/
	uint16_t timeout = I2C_TIMEOUT;

	while (I2C_BUSY == I2C_open_master(config, address) && --timeout)
	; // sit here until we get the bus..
	if (!timeout)
	return I2C_BUSY;
	I2C_set_data_complete_callback(I2C_wr1RegCompleteHandler, &data);
	I2C_set_buffer(&reg, 1);
	I2C_set_address_nack_callback(i2c_cb_restart_write, NULL); // NACK polling?
	I2C_master_write(config);
	timeout = I2C_TIMEOUT;
	while (I2C_BUSY == I2C_close_master(config) && --timeout)
	; // sit here until finished.
	if (!timeout)
	return I2C_FAIL;

	return I2C_NOERR;
}

/*
	I2C_writeNBytes
	Write N bytes to registers
	
	config - pointer to TWI_CONFIG object
	address - I2C address to write to
	data - pointer to bytes to write
	len - length of data to write
*/
i2c_error_t I2C_writeNBytes(TWI_CONFIG* config, i2c_address_t address, void *data, size_t len)
{
	/* timeout is used to get out of twim_release, when there is no device connected to the bus*/
	uint16_t timeout = I2C_TIMEOUT;

	while (I2C_BUSY == I2C_open_master(config, address) && --timeout)
	; // sit here until we get the bus..
	if (!timeout)
	return I2C_BUSY;
	I2C_set_buffer(data, len);
	I2C_set_address_nack_callback(i2c_cb_restart_write, NULL); // NACK polling?
	I2C_master_write(config);
	timeout = I2C_TIMEOUT;
	while (I2C_BUSY == I2C_close_master(config) && --timeout)
	; // sit here until finished.
	if (!timeout)
	return I2C_FAIL;

	return I2C_NOERR;
}

static i2c_operations_t I2C_rd1RegCompleteHandler(void *p)
{
	I2C_set_buffer(p, 1);
	I2C_set_data_complete_callback(NULL, NULL);
	return i2c_restart_read;
}

/*
	I2C_read1ByteRegister
	Read from a 1 Byte Register and return the value
	
	config - pointer to TWI_CONFIG object
	address - I2C address to read from
	reg - Register address to read from
*/
uint8_t I2C_read1ByteRegister(TWI_CONFIG* config, i2c_address_t address, uint8_t reg)
{
	uint8_t     d2 = 42;
	i2c_error_t e;
	int         x;

	for (x = 2; x != 0; x--) {
		while (!I2C_open_master(config, address))
		; // sit here until we get the bus..
		I2C_set_data_complete_callback(I2C_rd1RegCompleteHandler, &d2);
		I2C_set_buffer(&reg, 1);
		I2C_set_address_nack_callback(i2c_cb_restart_write, NULL); // NACK polling?
		I2C_master_write(config);
		while (I2C_BUSY == (e = I2C_close_master(config)))
		; // sit here until finished.
		if (e == I2C_NOERR)
		break;
	}

	return d2;
}

static i2c_operations_t I2C_rd2RegCompleteHandler(void *p)
{
	I2C_set_buffer(p, 2);
	I2C_set_data_complete_callback(NULL, NULL);
	return i2c_restart_read;
}

/*
	I2C_read2ByteRegister
	Read from a 2 Byte Register and return it as uint16_t
	
	config - pointer to TWI_CONFIG object
	address - I2C address to read from
	reg - Register address to read from
*/
uint16_t I2C_read2ByteRegister(TWI_CONFIG* config, i2c_address_t address, uint8_t reg)
{
	// result is little endian
	uint16_t result;

	while (!I2C_open_master(config, address))
	; // sit here until we get the bus..
	I2C_set_data_complete_callback(I2C_rd2RegCompleteHandler, &result);
	I2C_set_buffer(&reg, 1);
	I2C_set_address_nack_callback(i2c_cb_restart_write, NULL); // NACK polling?
	I2C_master_write(config);
	while (I2C_BUSY == I2C_close_master(config))
	; // sit here until finished.

	return (result << 8 | result >> 8);
}

static i2c_operations_t I2C_wr2RegCompleteHandler(void *p)
{
	I2C_set_buffer(p, 2);
	I2C_set_data_complete_callback(NULL, NULL);
	return i2c_continue;
}

/*
	I2C_write2ByteRegister
	Write to a 2 Byte Register
	
	config - pointer to TWI_CONFIG object
	address - I2C address to write to
	reg - Register address to write to
	data - Bytes to write
*/
i2c_error_t I2C_write2ByteRegister(TWI_CONFIG* config, i2c_address_t address, uint8_t reg, uint16_t data)
{
	/* timeout is used to get out of twim_release, when there is no device connected to the bus*/
	uint16_t timeout = I2C_TIMEOUT;

	while (I2C_BUSY == I2C_open_master(config, address) && --timeout)
	; // sit here until we get the bus..
	if (!timeout)
	return I2C_BUSY;
	I2C_set_data_complete_callback(I2C_wr2RegCompleteHandler, &data);
	I2C_set_buffer(&reg, 1);
	I2C_set_address_nack_callback(i2c_cb_restart_write, NULL); // NACK polling?
	I2C_master_write(config);
	timeout = I2C_TIMEOUT;
	while (I2C_BUSY == I2C_close_master(config) && --timeout)
	; // sit here until finished.
	if (!timeout)
	return I2C_FAIL;

	return I2C_NOERR;
}

typedef struct {
	size_t len;
	char * data;
} I2C_buf_t;

static i2c_operations_t I2C_rdBlkRegCompleteHandler(void *p)
{
	I2C_set_buffer(((I2C_buf_t *)p)->data, ((I2C_buf_t *)p)->len);
	I2C_set_data_complete_callback(NULL, NULL);
	return i2c_restart_read;
}

/*
	I2C_readNBytes
	Read a block of data from I2C
	
	config - pointer to TWI_CONFIG object
	address - I2C address to read from
	reg - Starting reg address
	data - array to store data read
	len - number of bytes to read
*/
i2c_error_t I2C_readDataBlock(TWI_CONFIG* config, i2c_address_t address, uint8_t reg, void *data, size_t len)
{
	/* timeout is used to get out of twim_release, when there is no device connected to the bus*/
	uint16_t timeout = I2C_TIMEOUT;
	// result is little endian
	I2C_buf_t d;
	d.data = data;
	d.len  = len;

	while (I2C_BUSY == I2C_open_master(config, address) && --timeout)
	; // sit here until we get the bus..
	if (!timeout)
	return I2C_BUSY;
	I2C_set_data_complete_callback(I2C_rdBlkRegCompleteHandler, &d);
	I2C_set_buffer(&reg, 1);
	I2C_set_address_nack_callback(i2c_cb_restart_write, NULL); // NACK polling?
	I2C_master_write(config);
	timeout = I2C_TIMEOUT;
	while (I2C_BUSY == I2C_close_master(config) && --timeout)
	; // sit here until finished.
	if (!timeout)
	return I2C_FAIL;

	return I2C_NOERR;
}

/*
	I2C_readNBytes
	Read N Bytes from I2C
	
	config - pointer to TWI_CONFIG object
	address - I2C address to read from
	data - array to store data read
	len - number of bytes to read
*/
i2c_error_t I2C_readNBytes(TWI_CONFIG* config, i2c_address_t address, void *data, size_t len)
{
	/* timeout is used to get out of twim_release, when there is no device connected to the bus*/
	uint16_t timeout = I2C_TIMEOUT;

	while (I2C_BUSY == I2C_open_master(config, address) && --timeout)
	; // sit here until we get the bus..
	if (!timeout)
	return I2C_BUSY;
	I2C_set_buffer(data, len);
	I2C_master_read(config);
	timeout = I2C_TIMEOUT;
	while (I2C_BUSY == I2C_close_master(config) && --timeout)
	; // sit here until finished.
	if (!timeout)
	return I2C_FAIL;

	return I2C_NOERR;
}
