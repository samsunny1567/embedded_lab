/*
 * application.h
 *
 * Created: 1/5/2024 5:41:12 PM
 *  Author: samsunny
 */ 


#ifndef APPLICATION_H_
#define APPLICATION_H_

void application_init();
void add_all_slave_commands();
void initialize_peripherals();


#endif /* APPLICATION_H_ */