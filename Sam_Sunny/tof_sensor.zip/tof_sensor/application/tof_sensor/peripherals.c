/*
 * initialize_mcu.c
 *
 * Created: 12/17/2023 7:04:49 AM
 *  Author: PramodVariyam
 */ 
#include "macros.h"
#include "headers.h"
#include "extern.h"


void initialize_peripherals()
{
	
	// System resources
	//-------------------

	mcu_init();

	CPUINT_init();

	// CPU clock
	SYSTEMCONFIG.clkCtrl.MCLKCTRLB.PDIV = 0x2 << 1;
	SYSTEMCONFIG.clkCtrl.MCLKCTRLA.CLKSEL = CLKCTRL_CLKSEL_EXTCLK_gc;
	SYSTEMCONFIG.clkCtrl.MCLKCTRLB.PEN = false;
	CLKCTRL_init();

	// SLPCTRL
	SLPCTRL_init();

	// BOD
	BOD_init();
	
	
	instantiateSystem();

	// Initialize all pins 
	instantiatePin(&GPIO_0, PIN_PORTA, 5);
	initializeOutputPin(GPIO_0 , false , PORT_PULL_OFF);
	
	instantiatePin(&GPIO_1, PIN_PORTF, 3);
	initializeOutputPin(GPIO_0 , false , PORT_PULL_OFF);
	
	instantiatePin(&EN , PIN_PORTF, 2);
	initializeOutputPin(EN , false , PORT_PULL_OFF);
	
	instantiatePin(&INT,PIN_PORTA,6);
	initializeInputPin(INT,PORT_PULL_OFF);
	
	instantiatePin(&COM0, PIN_PORTA,4);
	initializeOutputPin(COM0,false,PORT_PULL_OFF);


	// Initialize I2C 
	
    instantiatePin(&SDA , PIN_PORTA, 2);
    initializeOutputPin(SDA , false , PORT_PULL_OFF);

    instantiatePin(&SCL , PIN_PORTA , 3);
    initializeOutputPin(SCL , false , PORT_PULL_OFF);	
	
	instantiateTWI(&TWI_0,&TWI0,F_CPU,100000);
	initializeI2cMaster(&TWI_0);
	
	
	// Initialize UART 
	
	instantiatePin(&TXD , PIN_PORTC, 0);
	initializeOutputPin(TXD , false , PORT_PULL_OFF);
	
	instantiatePin(&RXD , PIN_PORTC, 1);
	initializeInputPin(RXD,PORT_PULL_OFF);

	USART_instantiate(&SLAVE_UART, &USART1, RXD, TXD, 9600, F_CPU);
	USART_initialize(&SLAVE_UART);
	
	
	TCA0.SINGLE.CTRLA= TCA_SINGLE_CLKSEL_DIV1_gc;
	instantiateTCA(&TCA0,&TCA_0,false);
	
	// Initialize the slave UART
	slave_uart_initialize(&SLAVE_UART);
} 

ISR(USART1_RXC_vect)
{
	slave_uart_default_rx_isr();
}

ISR(USART0_DRE_vect)
{
	slave_uart_default_tx_isr();
}