/*
 * tmf8701.h
 *
 * Created: 20-12-2023 09:58:42
 *  Author: nevil
 */ 


#ifndef TMF8701_H_
#define TMF8701_H_

typedef enum
{
	BOOTLOADER_RUNNING =        0x80,
	APP0_RUNNING =              0xC0,
	CALIBRATION_DATA_READY =    0x0A,
	SERIAL_NUMBER_READY =       0x47,
	RESULT_READY =              0x55,

}tmf_reg_contents;

typedef enum
{
	ENABLE_VALUE=0x01,
	CPU_READY=0x41,
	FACTORY_CAL=0x0A,
}tmf8701_cmds;


#define TMF8701_ADDRESS 0x41						// TMF8701 i2c slave address

typedef enum{
	
		APPID					=		0x00,		//Currently running application:
		APPREV_MAJOR			=		0x01,		//Application major revision
		APPREQID				=		0x02,		//Application that shall be started, set this to    0x80?. Boot loader    0xC0?. App0
		
		ENABLE					=		0xe0,		// Enable register
		INT_STATUS				=		0xe1,		// Interrupt status register
		INT_ENAB				=		0xe2,		// Interrupt enable register
		ID						=		0xe3,		// Chip ID, reads 07h
		REVID					=		0xe4,		// Chip revision ID
		
		CMD_DATA9				=		0x06,		// Command data 9 register
		CMD_DATA8				=		0x07,		// Command data 8 register
		CMD_DATA7				=		0x08,		// Command data 7 register
		CMD_DATA6				=		0x09,		// Command data 6 register
		CMD_DATA5				=		0x0a,		// Command data 5 register
		CMD_DATA4				=		0x0b,		// Command data 4 register
		CMD_DATA3				=		0x0c,		// Command data 3 register
		CMD_DATA2				=		0x0d,		// Command data 2 register
		CMD_DATA1				=		0x0e,		// Command data 1 register
		CMD_DATA0				=		0x0f,		// Command data 0 register
		
		COMMAND					=		0x10,		// Direct the device to control or select contents of the registers from 0x20...0xDF
		PREVIOUS				=		0x11,		// Previous command that was executed (or current if continues mode is selected)
		APPREV_MINOR			=		0x12,		// Application minor revision 
		APPREV_PATCH			=		0x13,		// Application patch number 
		
		
		STATUS					=		0x1d,		// Current status or current general operation 
		REGISTER_CONTENTS		=		0x1e,		// Current contents of the I?C ram from 0x20 to 0xEF;
		TID						=		0x1f,		// Unique transaction ID, changes with every update of register map by TOF
		RESULT_NUMBER			=		0x20,		// Result number, incremented every time there is a unique answer
		RESULT_INFO				=		0x21,		
		DISTANCE_PEAK_0			=		0x22,		// Distance to the peak in [mm] of the object, least significant byte
		DISTANCE_PEAK_1			=		0x23,		// Distance to the peak in [mm] of the object, most significant byte
		
		SYS_CLOCK_0				=		0x24,		// System clock/time stamp in units of 0.2?s
		SYS_CLOCK_1				=		0x25,		
		SYS_CLOCK_2				=		0x26,		
		SYS_CLOCK_3				=		0x27,		
		
		STATE_DATA_0			=		0x28,		// Algorithm state data
		STATE_DATA_1			=		0x29,		
		STATE_DATA_2			=		0x2a,		
		STATE_DATA_3			=		0x2b,		
		STATE_DATA_4			=		0x2c,		
		STATE_DATA_5			=		0x2d,		
		STATE_DATA_6			=		0x2e,		
		STATE_DATA_7			=		0x2f,		
		STATE_DATA_8			=		0x30,		
		STATE_DATA_9			=		0x31,		
		STATE_DATA_10			=		0x32,		
		
		REFERENCE_HITS_0		=		0x33,		// Sum of the reference SPADs hits during the distance measurement; zero if no object is detected or distance algorithm is no used
		REFERENCE_HITS_1		=		0x34,
		REFERENCE_HITS_2		=		0x35,
		REFERENCE_HITS_3		=		0x36,
		
		OBJECT_HITS_0			=		0x37,		//	Sum of the reference SPADs hits during the distance measurement; zero if no object is detected or distance algorithm is no used
		OBJECT_HITS_1			=		0x38,
		OBJECT_HITS_2			=		0x39,
		OBJECT_HITS_3			=		0x3a,
		
		FACTORY_CALIB_0			=		0x20,		// Factory calibration data
	/*	FACTORY_CALIB_1			=		0x21,
		FACTORY_CALIB_2			=		0x22,
		FACTORY_CALIB_3			=		0x23,
		FACTORY_CALIB_4			=		0x24,
		FACTORY_CALIB_5			=		0x25,
		FACTORY_CALIB_6			=		0x26,
		FACTORY_CALIB_7			=		0x27,
		FACTORY_CALIB_8			=		0x28,
		FACTORY_CALIB_9			=		0x29,
		FACTORY_CALIB_10		=		0x2a,
		FACTORY_CALIB_11		=		0x2b,
		FACTORY_CALIB_12		=		0x2c,
		FACTORY_CALIB_13		=		0x2d,*/
	
		STATE_DATA_WR_0			=		0x2e,		// Algorithm state data
		STATE_DATA_WR_1			=		0x2f,
		STATE_DATA_WR_2			=		0x30,
		STATE_DATA_WR_3			=		0x31,
		STATE_DATA_WR_4			=		0x32,
		STATE_DATA_WR_5			=		0x33,
		STATE_DATA_WR_6			=		0x34,
		STATE_DATA_WR_7			=		0x35,
		STATE_DATA_WR_8			=		0x36,
		STATE_DATA_WR_9			=		0x37,
		STATE_DATA_WR_10		=		0x38,
		
		HISTOGRAM_START			=		0x20,		// Quarter of histogram first byte 
		HISTOGRAM_END			=		0x9f,
		
		
		SERIAL_NUMBER_0			=		0x28,		// Serial number byte 0 
		SERIAL_NUMBER_1			=		0x29,		// Serial number byte 1 
		IDENTIFICATION_NUMBER_0	=		0x2a,		// Identification number byte 0
		IDENTIFICATION_NUMBER_1	=		0x2b,		// Identification number byte 1

	}tmf_reg_init;



#endif /* TMF8701_H_ */