/*
 * uart_commands.h
 *
 * Created: 12/28/2023 11:19:27 AM
 *  Author: samsunny
 */ 


#ifndef UART_COMMANDS_H_
#define UART_COMMANDS_H_

typedef enum{
	GET_FW_VERSION				=			0x00,
	GET_MODULE_NAME				=			0x01,
	GET_FLASH_DATE				=			0x02,
	GET_SERIAL_NUMBER			=			0x03,
	
	
	TOF_SET_ENABLE				=			0x10,
	TOF_GET_ENABLE				=			0x11,
	GET_TOF_CPU_STATUS			=			0x12,
	TOF_DISTANCE_RANGE			=			0x13,
	
	
	START_FACTORY_CAL			=			0x20,
	LOAD_FACTORY_CAL			=			0x21,
	SET_DISTANCE_LIMITS			=			0x22,
	SET_INTERRUPT_MODE			=			0x23,
	SET_MEASUREMENT_UPDATE_PER	=			0x24,
	GET_DISTANCE				=			0x25,
	
	
	READ_ERROR					=			0xff,
	
}UART_COMMANDS;



#endif /* UART_COMMANDS_H_ */