/*
 * extern.h
 *
 * Created: 18-12-2023 12:19:57
 *  Author: nevil
 */ 


#ifndef EXTERN_H_
#define EXTERN_H_

extern PIN_OBJ GPIO_0;
extern PIN_OBJ GPIO_1;
extern PIN_OBJ INT;
extern PIN_OBJ EN;

extern PIN_OBJ COM0;
extern PIN_OBJ TXD;
extern PIN_OBJ RXD;

extern PIN_OBJ SDA;
extern PIN_OBJ SCL;
extern USART_CONFIG SLAVE_UART;

extern TWI_CONFIG TWI_0;
extern TWI_t  SLAVE_REGISTER;

extern uint8_t cal_data[14];
extern TCA_CONFIG TCA_0;


#endif /* EXTERN_H_ */