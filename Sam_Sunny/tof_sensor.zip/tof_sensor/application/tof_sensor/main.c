/*
 * tof_sensor.c
 *
 * Created: 12/11/2023 9:14:55 PM
 * Author : PramodVariyam
 */ 

#include <avr/io.h>
#include "headers.h"
#include "globals.h"
#include "application.h"
i2c_error_t err_var;
uint8_t output;

int main(void)
{
	application_init();
	setPinLevel(&EN,true);
	err_var = I2C_write1ByteRegister(&TWI_0,TMF8701_ADDRESS,0xe0,0x01);
	
    /* Replace with your application code */
    while (1) 
    {
		//process_uart_command();
		output = I2C_read1ByteRegister(&TWI_0,TMF8701_ADDRESS,0xe0);
    }
}


