/*
 * system.h
 *
 * Created: 10/23/2023 2:12:19 PM
 *  Author: BenSchnuck
 */ 


#ifndef SYSTEM_DRIVER_H_
#define SYSTEM_DRIVER_H_

typedef struct {
	bool SAMPFREQ;
	BOD_ACTIVE_t ACTIVE;
	BOD_SLEEP_t SLEEP;
}BOD_CTRLA_CONFIG;

typedef struct {
	BOD_LVL_t LVL;
}BOD_CTRLB_CONFIG;

typedef struct {
	bool VLMIE;
	bool VLMCFG;
}BOD_INTCTRL_CONFIG;

typedef struct {
	bool IVSEL;
	bool CVT;
	bool LVL0RR;
}CPUINT_CTRLA_CONFIG;

typedef struct {
	SLPCTRL_SMODE_t SMODE;
	bool SEN;
}SLPCTRL_CTRLA_CONFIG;

typedef struct {
	bool CLKOUT;
	CLKCTRL_CLKSEL_t CLKSEL;
}CLKCTRL_MCLKCTRLA_CONFIG;

typedef struct {
	CLKCTRL_PDIV_t PDIV;
	bool PEN;
}CLKCTRL_MCLKCTRLB_CONFIG;

typedef struct {
	bool LOCKEN;
}CLKCTRL_MCLKLOCK_CONFIG;

typedef struct {
	bool RUNSTDBY;
}CLKCTRL_OSC20MCTRLA_CONFIG;

typedef struct {
	bool RUNSTDBY;
}CLKCTRL_OSC32KCTRLA_CONFIG;

typedef struct {
	CLKCTRL_CSUT_t CSUT;
	bool SEL;
	bool RUNSTDBY;
	bool ENABLE;
}CLKCTRL_XOSC32KCTRLA_CONFIG;


typedef struct {
	BOD_CTRLA_CONFIG CTRLA;
	BOD_CTRLB_CONFIG CTRLB;
	BOD_INTCTRL_CONFIG INTCTRL;
	BOD_VLMLVL_t VLMLVL;
}BOD_CONFIG;

typedef struct {
	CPUINT_CTRLA_CONFIG CTRLA;
	uint8_t LVL0PRI;
	uint8_t LVL1VEC;
}CPUINT_CONFIG;

typedef struct {
	SLPCTRL_CTRLA_CONFIG CTRLA;
}SLPCTRL_CONFIG;

typedef struct {
	CLKCTRL_MCLKCTRLA_CONFIG MCLKCTRLA;
	CLKCTRL_MCLKCTRLB_CONFIG MCLKCTRLB;
	CLKCTRL_MCLKLOCK_CONFIG MCLKLOCK;
	CLKCTRL_OSC20MCTRLA_CONFIG OSC20MCTRLA;
	CLKCTRL_OSC32KCTRLA_CONFIG OSC32KCTRLA;
	CLKCTRL_XOSC32KCTRLA_CONFIG XOSC32KCTRLA;
}CLKCTRL_CONFIG;

typedef struct {
	BOD_CONFIG bod;
	CPUINT_CONFIG cpuInt;
	SLPCTRL_CONFIG slpCtrl;
	CLKCTRL_CONFIG clkCtrl;
}SYSTEM_CONFIG;

SYSTEM_CONFIG SYSTEMCONFIG;

typedef enum {
	RST_PORF = 0,
	RST_BORF = 1,
	RST_EXTRF = 2,
	RST_WDRF = 3,
	RST_SWRF = 4,
	RST_UPDIRF = 5,
}RST_FLAGS;

void instantiateSystem(void);

void mcu_init(void);
int8_t CLKCTRL_init(void);
int8_t BOD_init(void);
int8_t CPUINT_init(void);
int8_t SLPCTRL_init(void);
void SLPCTRL_set_sleep_mode(SLPCTRL_SMODE_t setmode);
uint8_t RSTCTRL_get_reset_cause(void);
void RSTCTRL_clear_reset_cause(void);
void RSTCTRL_reset_flag(RST_FLAGS flag);

void default_CLKCTRL_settings(void);
int8_t CLKCTRL_init(void);

#endif /* SYSTEM_DRIVER_H_ */