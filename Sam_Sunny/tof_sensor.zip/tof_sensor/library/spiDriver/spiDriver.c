/*
 * spiDriver.c
 *
 * Created: 10/20/2023 1:43:48 PM
 * Author : BenSchnuck
 */ 

#include <avr/io.h>
#include <stdbool.h>
#include <stddef.h>
#include "gpioDriver.h"
#include "spiDriver.h"

/*
	void defaultSpiConfigSettings
	Populate passed config object with default values
	
	config - pointer to SPI_CONFIG settings object
*/
void defaultSpiConfigSettings(SPI_CONFIG* config) {
	config->CTRLA.ENABLE = true;
	config->CTRLA.MASTER = true;
	
	config->INTCTRL.IE = true;
}

/*
	void spiInit
	Initialize spi config object and passed spi object. Also sets up SPI gpio pins
	
	config - SPI_CONFIG settings object
	spi - pointer to SPI_t object to attach to config
	altPins - Use/Don't Use alternate SPI gpio pins
*/
void spiInit(SPI_CONFIG config, SPI_t* spi, bool altPins) {
	config.spi = spi;
	
	PIN_OBJ MISO;
	PIN_OBJ MOSI;
	PIN_OBJ SCLK;
	
	if(config.CTRLA.MASTER) {
		setupSpiPins(MISO, MOSI, SCLK, altPins);
		setPinLevel(&SCLK, false);
		setPinDir(&SCLK, PORT_DIR_OUT);
	} else {
		setupSpiPins(MOSI, MISO, SCLK, altPins);
		setPinDir(&SCLK, PORT_DIR_IN);
		setPinPullMode(&SCLK, PORT_PULL_OFF);
	}
	
	config.status = SPI_FREE;
	updateSpiRegisters(config);
}

/*
	void spiEnable
	Enable the spi module
	
	config - SPI_CONFIG settings object
*/
void spiEnable(SPI_CONFIG config) {
	config.CTRLA.ENABLE = true;
	setSpiCTRLA(config);
}

/*
	void spiDisable
	Disable the spi module
	
	config - SPI_CONFIG settings object
*/
void spiDisable(SPI_CONFIG config) {
	config.CTRLA.ENABLE = false;
	setSpiCTRLA(config);
}

/*
	void spiDefaultISR
	Default ISR function for SPI communication
	
	config - SPI_CONFIG settings object
*/
void spiDefaultISR(SPI_CONFIG config) {
	uint8_t rdata = config.spi->DATA;
	uint8_t wdata = 0;
	
	if (config.type != SPI_WRITE) {
		*config.data = rdata;
	}
	
	config.data++;
	
	if (config.type != SPI_READ) {
		wdata = *config.data;
	}
	
	config.size--;
	
	if (config.size != 0) {
		config.spi->DATA = wdata;
	}
	else {
		config.status = SPI_DONE;
		setSpiSS(config, config.active_SS_index, false);
	}
}

/*
	bool spiStatusFree
	Return true is SPI status is FREE
	
	config - SPI_CONFIG settings object
*/
bool spiStatusFree(SPI_CONFIG config) {
	return (config.status == SPI_FREE);
}

/*
	bool spiStatusIdle
	Return true is SPI status is IDLE
	
	config - SPI_CONFIG settings object
*/
bool spiStatusIdle(SPI_CONFIG config) {
	return (config.status == SPI_IDLE);
}

/*
	bool spiStatusBusy
	Return true is SPI status is BUSY
	
	config - SPI_CONFIG settings object
*/
bool spiStatusBusy(SPI_CONFIG config) {
	return (config.status == SPI_BUSY);
}

/*
	bool spiStatusDone
	Return true is SPI status is DONE
	
	config - SPI_CONFIG settings object
*/
bool spiStatusDone(SPI_CONFIG config) {
	return (config.status == SPI_DONE);
}

/*
	uint8_t spiExchangeByte
	Exchange a byte via SPI communication
	
	config - SPI_CONFIG settings object
	data - Data to exchange
	slave_select_index - Index of SS array to enable for communication
*/
uint8_t spiExchangeByte(SPI_CONFIG config, uint8_t data, uint8_t slave_select_index) {
	setSpiSS(config, slave_select_index, true);
	config.active_SS_index = slave_select_index;
	
	config.data = (uint8_t *)&data;
	config.size = 1;
	config.type = SPI_READ;
	config.status = SPI_BUSY;
	
	config.spi->DATA = *config.data;
	while (config.status == SPI_BUSY);
	setSpiSS(config, slave_select_index, false);
	
	return data;
}

/*
	void spiExchangeBlock
	Exchange a block of data between the master and slave
	
	config - SPI_CONFIG settings object
	block - data to send and place to store incoming data
	size - size (length) of the data
	slave_select_index - Index of SS array to enable for communication
*/
void spiExchangeBlock(SPI_CONFIG config, void *block, uint8_t size, uint8_t slave_select_index) {
	setSpiSS(config, slave_select_index, true);
	config.active_SS_index = slave_select_index;
	
	config.data = (uint8_t *)block;
	config.size = size;
	config.type = SPI_WRITE;
	config.status = SPI_BUSY;
	
	config.spi->DATA = *config.data;
}

/*
	void spiWriteBlock
	Write a block of data via SPI communication
	
	config - SPI_CONFIG settings object
	block - data to send
	size - size (length) of the data
	slave_select_index - Index of SS array to enable for communication
*/
void spiWriteBlock(SPI_CONFIG config, void *block, uint8_t size, uint8_t slave_select_index) {
	setSpiSS(config, slave_select_index, true);
	config.active_SS_index = slave_select_index;
	
	config.data = (uint8_t*)block;
	config.size = size;
	config.type = SPI_WRITE;
	config.status = SPI_BUSY;
	
	config.spi->DATA = *config.data;
}

/*
	void spiReadBlock
	Read a block of data via SPI communication
	
	config - SPI_CONFIG settings object
	block - place to store data 
	size - size (length) of data to read
	slave_select_index - Index of SS array to enable for communication
*/
void spiReadBlock(SPI_CONFIG config, void *block, uint8_t size, uint8_t slave_select_index) {
	setSpiSS(config, slave_select_index, true);
	config.active_SS_index = slave_select_index;
	
	config.data = (uint8_t*)block;
	config.size = size;
	config.type = SPI_READ;
	config.status = SPI_BUSY;
	
	config.spi->DATA = 0;
}