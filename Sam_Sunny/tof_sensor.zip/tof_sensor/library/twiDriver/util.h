/*
 * util.h
 *
 * Created: 10/23/2023 1:55:55 PM
 *  Author: BenSchnuck
 */ 


#ifndef UTIL_H_
#define UTIL_H_

#include <avr/io.h>
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>

#endif /* UTIL_H_ */