/*
 * twiDriver.h
 *
 * Created: 10/23/2023 11:12:09 AM
 *  Author: BenSchnuck
 */ 


#ifndef TWIDRIVER_H_
#define TWIDRIVER_H_

typedef enum {
	TWI_I2C=0,
}TWI_MODE;

typedef struct {
	bool SDASETUP;
	TWI_SDAHOLD_t SDAHOLD;
	bool FMPEN;
}TWI_CTRLA_CONFIG;

typedef struct {
	TWI_SDAHOLD_t SDAHOLD;
	bool FMPEN;
	bool ENABLE;
}TWI_DUALCTRL_CONFIG;

typedef struct {
	bool DBGRUN;	
}TWI_DBGCTRL_CONFIG;

typedef struct {
	bool RIEN;
	bool WIEN;
	bool QCEN;
	TWI_TIMEOUT_t TIMEOUT;
	bool SMEN;
	bool ENABLE;
}TWI_MCTRLA_CONFIG;

typedef struct {
	bool FLUSH;
	bool ACKACT;
	TWI_MCMD_t MCMD;
}TWI_MCTRLB_CONFIG;

typedef struct {
	bool RIF;
	bool WIF;
	bool CLKHOLD;
	// RXACK - Read only
	bool ARBLOST;
	bool BUSERR;
	TWI_BUSSTATE_t BUSSTATE;
}TWI_MSTATUS_CONFIG;

typedef struct {
	bool DIEN;
	bool APIEN;
	bool PIEN;
	bool PMEN;
	bool SMEN;
	bool ENABLE;
}TWI_SCTRLA_CONFIG;

typedef struct {
	bool ACKACT;
	TWI_SCMD_t SCMD;
}TWI_SCTRLB_CONFIG;

typedef struct {
	bool DIF;
	bool APIF;
	bool COLL;
	bool BUSERR;
}TWI_SSTATUS_CONFIG;

typedef struct {
	uint8_t ADDRMASK;
	bool ADDREN;
}TWI_SADDRMASK_CONFIG;

typedef struct {
	TWI_t* twi;
	TWI_MODE mode;
	float cpu_clk;
	float baud;
	
	TWI_CTRLA_CONFIG CTRLA;
	TWI_DUALCTRL_CONFIG DUALCTRL;
	TWI_DBGCTRL_CONFIG DBGCTRL;
	TWI_MCTRLA_CONFIG MCTRLA;
	TWI_MCTRLB_CONFIG MCTRLB;
	TWI_MSTATUS_CONFIG MSTATUS;
	uint8_t MBAUD;
	uint8_t MADDR;
	uint8_t MDATA;
	TWI_SCTRLA_CONFIG SCTRLA;
	TWI_SCTRLB_CONFIG SCTRLB;
	TWI_SSTATUS_CONFIG SSTATUS;
	uint8_t SADDR;
	uint8_t SDATA;
	TWI_SADDRMASK_CONFIG SADDRMASK;
}TWI_CONFIG;

static inline void setTwiCTRLA(TWI_CONFIG config) {
	config.twi->CTRLA = config.CTRLA.SDASETUP << TWI_SDASETUP_bp
						| config.CTRLA.FMPEN << TWI_FMPEN_bp
						| config.CTRLA.SDAHOLD;
}

static inline void setTwiDUALCTRL(TWI_CONFIG config) {
	config.twi->DUALCTRL = config.DUALCTRL.ENABLE << TWI_ENABLE_bp
						| config.DUALCTRL.FMPEN << TWI_FMPEN_bp
						| config.DUALCTRL.SDAHOLD;
}

static inline void setTwiDBGCTRL(TWI_CONFIG config) {
	config.twi->DBGCTRL = config.DBGCTRL.DBGRUN << TWI_DBGRUN_bp;
}

static inline void setTwiMCTRLA(TWI_CONFIG config) {
	config.twi->MCTRLA = config.MCTRLA.ENABLE << TWI_ENABLE_bp
						| config.MCTRLA.QCEN << TWI_QCEN_bp
						| config.MCTRLA.RIEN << TWI_RIEN_bp
						| config.MCTRLA.SMEN << TWI_SMEN_bp
						| config.MCTRLA.TIMEOUT
						| config.MCTRLA.WIEN << TWI_WIEN_bp;
}

static inline void setTwiMCTRLB(TWI_CONFIG config) {
	config.twi->MCTRLB = config.MCTRLB.ACKACT << TWI_ACKACT_bp
						| config.MCTRLB.FLUSH << TWI_FLUSH_bp
						| config.MCTRLB.MCMD;
						
	config.MCTRLB.FLUSH = false;
}

static inline void setTwiMSTATUS(TWI_CONFIG config) {
	config.twi->MSTATUS = config.MSTATUS.ARBLOST << TWI_ARBLOST_bp
						| config.MSTATUS.BUSERR << TWI_BUSERR_bp
						| config.MSTATUS.BUSSTATE
						| config.MSTATUS.CLKHOLD << TWI_CLKHOLD_bp
						| config.MSTATUS.RIF << TWI_RIF_bp
						| config.MSTATUS.WIF << TWI_WIF_bp;
	
	config.MSTATUS.ARBLOST = false;
	config.MSTATUS.BUSERR = false;
	config.MSTATUS.BUSSTATE = false;
	config.MSTATUS.CLKHOLD = false;
	config.MSTATUS.RIF = false;
	config.MSTATUS.WIF = false;
}

static inline void setTwiMBAUD(TWI_CONFIG config) {
	config.twi->MBAUD = config.MBAUD;
}

static inline void setTwiMADDR(TWI_CONFIG config) {
	config.twi->MADDR = config.MADDR;
}

static inline void setTwiMDATA(TWI_CONFIG config) {
	config.twi->MDATA = config.MDATA;
}

static inline void setTwiSCTRLA(TWI_CONFIG config) {
	config.twi->SCTRLA = config.SCTRLA.APIEN << TWI_APIEN_bp
						| config.SCTRLA.DIEN << TWI_DIEN_bp
						| config.SCTRLA.ENABLE << TWI_ENABLE_bp
						| config.SCTRLA.PIEN << TWI_PIEN_bp
						| config.SCTRLA.PMEN << TWI_PMEN_bp
						| config.SCTRLA.SMEN << TWI_SMEN_bp;
}

static inline void setTwiSCTRLB(TWI_CONFIG config) {
	config.twi->SCTRLB = config.SCTRLB.ACKACT << TWI_ACKACT_bp
						| config.SCTRLB.SCMD;
}

static inline void setTwiSSTATUS(TWI_CONFIG config) {
	config.twi->SSTATUS = config.SSTATUS.APIF << TWI_APIF_bp
						| config.SSTATUS.BUSERR << TWI_BUSERR_bp
						| config.SSTATUS.COLL << TWI_COLL_bp
						| config.SSTATUS.DIF << TWI_DIF_bp;
}

static inline void setTwiSADDR(TWI_CONFIG config) {
	config.twi->SADDR = config.SADDR;
}

static inline void setTwiSDATA(TWI_CONFIG config) {
	config.twi->SDATA = config.SDATA;
}

static inline void setTwiSADDRMASK(TWI_CONFIG config) {
	if (config.SADDRMASK.ADDRMASK > 0x7F) config.SADDRMASK.ADDRMASK = 0x7F; // limit to 7 bits
	config.twi->SADDRMASK = config.SADDRMASK.ADDREN << TWI_ADDREN_bp
							| config.SADDRMASK.ADDRMASK << TWI_ADDRMASK_gp;
}

static inline void updateTwiRegisters(TWI_CONFIG config) {
	setTwiCTRLA(config);
	setTwiDUALCTRL(config);
	setTwiDBGCTRL(config);
	setTwiMCTRLA(config);
	setTwiMCTRLB(config);
	setTwiMSTATUS(config);
	setTwiMBAUD(config);
	setTwiMADDR(config);
	setTwiMDATA(config);
	setTwiSCTRLA(config);
	setTwiSCTRLB(config);
	setTwiSSTATUS(config);
	setTwiSADDR(config);
	setTwiSDATA(config);
	setTwiSADDRMASK(config);
}

void instantiateTWI(TWI_CONFIG* config, TWI_t* twi, float cpu_clk, float baud);
void initializeI2cMaster(TWI_CONFIG* config);

#endif /* TWIDRIVER_H_ */