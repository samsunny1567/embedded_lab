/*
 * i2cMaster.c
 *
 * Created: 12/18/2023 12:27:34 PM
 *  Author: BenSchnuck
 */ 

#include "i2cMaster.h"

// I2C STATES
typedef enum {
	I2C_IDLE = 0,
	I2C_SEND_ADR_READ,
	I2C_SEND_ADR_WRITE,
	I2C_TX,
	I2C_RX,
	I2C_TX_EMPTY,
	I2C_SEND_RESTART_READ,
	I2C_SEND_RESTART_WRITE,
	I2C_SEND_RESTART,
	I2C_SEND_STOP,
	I2C_RX_DO_ACK,
	I2C_TX_DO_ACK,
	I2C_RX_DO_NACK_STOP,
	I2C_RX_DO_NACK_RESTART,
	I2C_RESET,
	I2C_ADDRESS_NACK,
	I2C_BUS_COLLISION,
	I2C_BUS_ERROR
} i2c_fsm_states_t;

// I2C Event Callback List
typedef enum {
	i2c_dataComplete = 0,
	i2c_writeCollision,
	i2c_addressNACK,
	i2c_dataNACK,
	i2c_timeOut,
	i2c_NULL
} i2c_callback_index;

// I2C Status Structure
typedef struct {
	unsigned         busy : 1;
	unsigned         inUse : 1;
	unsigned         bufferFree : 1;
	unsigned         addressNACKCheck : 1;
	i2c_address_t    address;       /// The I2C Address
	uint8_t *        data_ptr;      /// pointer to a data buffer
	size_t           data_length;   /// Bytes in the data buffer
	uint16_t         timeout;       /// I2C Timeout Counter between I2C Events.
	uint16_t         timeout_value; /// Reload value for the timeouts
	i2c_fsm_states_t state;         /// Driver State
	i2c_error_t      error;
	/*if timeoutDriverEnabled
	timerStruct_t timeout;
	*/
	i2c_callback callbackTable[6];
	void *       callbackPayload[6]; ///  each callback can have a payload
} i2c_status_t;


typedef i2c_fsm_states_t(stateHandlerFunction)(TWI_CONFIG* config);

i2c_status_t I2C_status = {0};
	
static void             I2C_set_callback(i2c_callback_index idx, i2c_callback cb, void *p);
static i2c_operations_t I2C_return_stop(void *p);
static i2c_operations_t I2C_return_reset(void *p);
static i2c_fsm_states_t I2C_do_I2C_SEND_ADR_READ(TWI_CONFIG* config);
static i2c_fsm_states_t I2C_do_I2C_SEND_ADR_WRITE(TWI_CONFIG* config);
//void             I2C_master_default_isr(TWI_CONFIG* config);


/**
 * \brief Set callback to be called when all specifed data has been transferred.
 *
 * \param[in] cb Pointer to callback function
 * \param[in] p  Pointer to the callback function's parameters
 *
 * \return Nothing
 */
void I2C_set_data_complete_callback(i2c_callback cb, void *p)
{
	I2C_set_callback(i2c_dataComplete, cb, p);
}

/**
 * \brief Set callback to be called when there has been a bus collision and arbitration was lost.
 *
 * \param[in] cb Pointer to callback function
 * \param[in] p  Pointer to the callback function's parameters
 *
 * \return Nothing
 */
void I2C_set_write_collision_callback(i2c_callback cb, void *p)
{
	I2C_set_callback(i2c_writeCollision, cb, p);
}

/**
 * \brief Set callback to be called when the transmitted address was NACK'ed.
 *
 * \param[in] cb Pointer to callback function
 * \param[in] p  Pointer to the callback function's parameters
 *
 * \return Nothing
 */
void I2C_set_address_nack_callback(i2c_callback cb, void *p)
{
	I2C_set_callback(i2c_addressNACK, cb, p);
}

/**
 * \brief Set callback to be called when the transmitted data was NACK'ed.
 *
 * \param[in] cb Pointer to callback function
 * \param[in] p  Pointer to the callback function's parameters
 *
 * \return Nothing
 */
void I2C_set_data_nack_callback(i2c_callback cb, void *p)
{
	I2C_set_callback(i2c_dataNACK, cb, p);
}

/**
 * \brief Set callback to be called when there was a bus timeout.
 *
 * \param[in] cb Pointer to callback function
 * \param[in] p  Pointer to the callback function's parameters
 *
 * \return Nothing
 */
void I2C_set_timeout_callback(i2c_callback cb, void *p)
{
	I2C_set_callback(i2c_timeOut, cb, p);
}

void I2C_init_master(TWI_CONFIG* config)
{

	// TWI0.CTRLA = 0 << TWI_FMPEN_bp /* FM Plus Enable: disabled */
	//		 | TWI_SDAHOLD_OFF_gc /* SDA hold time off */
	//		 | TWI_SDASETUP_4CYC_gc; /* SDA setup time is 4 clock cycles */

	// TWI0.DBGCTRL = 0 << TWI_DBGRUN_bp; /* Debug Run: disabled */

	config->MBAUD = (uint8_t)TWI_BAUD(config->cpu_clk, config->baud, 0); /* set MBAUD register */
	
	config->MCTRLA.ENABLE = true;
	config->MCTRLA.RIEN = true;
	config->MCTRLA.WIEN = true;
	
	setTwiMBAUD(*config);
	setTwiMCTRLA(*config);
}

/**
 * \brief Open the I2C for communication
 *
 * \param[in] address The slave address to use in the transfer
 *
 * \return Initialization status.
 * \retval I2C_NOERR The I2C open was successful
 * \retval I2C_BUSY  The I2C open failed because the interface is busy
 * \retval I2C_FAIL  The I2C open failed with an error
 */
i2c_error_t I2C_open_master(TWI_CONFIG* config, i2c_address_t address)
{
	i2c_error_t ret = I2C_BUSY;

	if (!I2C_status.inUse) {
		I2C_status.address          = address;
		I2C_status.busy             = 0;
		I2C_status.inUse            = 1;
		I2C_status.addressNACKCheck = 0;
		I2C_status.state            = I2C_RESET;
		I2C_status.timeout_value    = 500; // MCC should determine a reasonable starting value here.
		I2C_status.bufferFree       = 1;
		/*
		        <#if timeoutDriverEnabled>
		        I2C_status.timeout.callbackPtr = ${i2cMasterFunctions["timeoutHandler"]};
		        </#if>
		*/
		// set all the call backs to a default of sending stop
		I2C_status.callbackTable[i2c_dataComplete]     = I2C_return_stop;
		I2C_status.callbackPayload[i2c_dataComplete]   = NULL;
		I2C_status.callbackTable[i2c_writeCollision]   = I2C_return_stop;
		I2C_status.callbackPayload[i2c_writeCollision] = NULL;
		I2C_status.callbackTable[i2c_addressNACK]      = I2C_return_stop;
		I2C_status.callbackPayload[i2c_addressNACK]    = NULL;
		I2C_status.callbackTable[i2c_dataNACK]         = I2C_return_stop;
		I2C_status.callbackPayload[i2c_dataNACK]       = NULL;
		I2C_status.callbackTable[i2c_timeOut]          = I2C_return_reset;
		I2C_status.callbackPayload[i2c_timeOut]        = NULL;

		config->MCTRLB.FLUSH = true;
		
		config->MSTATUS.BUSSTATE = true;
		config->MSTATUS.RIF = true;
		config->MSTATUS.WIF = true;
		
		config->MCTRLA.RIEN = true;
		config->MCTRLA.WIEN = true;
		
		setTwiMCTRLB(*config);
		setTwiMSTATUS(*config);
		setTwiMCTRLA(*config);

		ret = I2C_NOERR;
	}
	return ret;
}

void I2C_set_address(i2c_address_t address)
{
	I2C_status.address = address;
}

/**
 * \brief Close the I2C interface
 *
 * \return Status of close operation.
 * \retval I2C_NOERR The I2C close was successful
 * \retval I2C_BUSY  The I2C close failed because the interface is busy
 * \retval I2C_FAIL  The I2C close failed with an error
 */
i2c_error_t I2C_close_master(TWI_CONFIG* config)
{
	i2c_error_t ret = I2C_BUSY;
	// Bus is in error state, reset I2C hardware and report error
	if (config->twi->MSTATUS & TWI_BUSERR_bm) {
		I2C_status.busy  = false;
		I2C_status.error = I2C_FAIL;
	}
	if (!I2C_status.busy) {
		I2C_status.inUse = 0;
		// close it down
		I2C_status.address = 0xff; // 8-bit address is invalid so this is FREE
		
		config->MSTATUS.RIF = true;
		config->MSTATUS.WIF = true;
		setTwiMSTATUS(*config);
		
		config->MCTRLA.RIEN = false;
		config->MCTRLA.WIEN = false;
		setTwiMCTRLA(*config);
		
		ret = I2C_status.error;
	}
	return ret;
}

/**
 * \brief Set timeout to be used for I2C operations. Uses the Timeout driver.
 *
 * \param[in] to Timeout in ticks
 *
 * \return Nothing
 */
void I2C_set_timeout(TWI_CONFIG* config, uint8_t to)
{
	config->MCTRLA.RIEN = false;
	config->MCTRLA.WIEN = false;
	setTwiMCTRLA(*config);
	I2C_status.timeout_value = to;
	config->MCTRLA.RIEN = true;
	config->MCTRLA.WIEN = true;
	setTwiMCTRLA(*config);
}

/**
 * \brief Set baud rate to be used for I2C operations.
 *
 * \param[in] baud to set the transfer speed
 *
 * \return Nothing
 */
void I2C_set_baud_rate(TWI_CONFIG* config, uint32_t baud)
{
	config->baud = baud;
	config->twi->MBAUD = (uint8_t)TWI_BAUD(config->cpu_clk, config->baud, 0); /* set MBAUD register */
}

/**
 * \brief Sets up the data buffer to use, and number of bytes to transfer
 *
 * \param[in] buffer Pointer to data buffer to use for read or write data
 * \param[in] bufferSize Number of bytes to read or write from slave
 *
 * \return Nothing
 */
void I2C_set_buffer(void *buffer, size_t bufferSize)
{
	if (I2C_status.bufferFree) {
		I2C_status.data_ptr    = buffer;
		I2C_status.data_length = bufferSize;
		I2C_status.bufferFree  = false;
	}
}

/**
 * \brief Start an operation on an opened I2C interface
 *
 * \param[in] read Set to true for read, false for write
 *
 * \return Status of operation
 * \retval I2C_NOERR The I2C open was successful
 * \retval I2C_BUSY  The I2C open failed because the interface is busy
 * \retval I2C_FAIL  The I2C open failed with an error
 */
i2c_error_t I2C_master_operation(TWI_CONFIG* config, bool read)
{
	i2c_error_t ret = I2C_BUSY;
	if (!I2C_status.busy) {
		I2C_status.busy = true;
		ret               = I2C_NOERR;

		if (read) {
			I2C_status.state = I2C_SEND_ADR_READ;
		} else {
			I2C_status.state = I2C_SEND_ADR_WRITE;
		}
		I2C_master_default_isr(config);
	}
	return ret;
}

/**
 * \brief Identical to I2C_master_operation(true);
 */
i2c_error_t I2C_master_read(TWI_CONFIG* config)
{
	return I2C_master_operation(config, true);
}

/**
 * \brief Identical to I2C_master_operation(false);
 */
i2c_error_t I2C_master_write(TWI_CONFIG* config)
{
	return I2C_master_operation(config, false);
}


/************************************************************************/
/* Helper Functions                                                     */
/************************************************************************/

static i2c_fsm_states_t I2C_do_I2C_RESET(TWI_CONFIG* config)
{
	config->MCTRLB.FLUSH = true;
	setTwiMCTRLB(*config);
	
	config->MSTATUS.BUSSTATE = true;
	setTwiMSTATUS(*config);
	
	I2C_status.busy  = false; // Bus Free
	I2C_status.error = I2C_NOERR;
	return I2C_RESET; // park the FSM on reset
}

static i2c_fsm_states_t I2C_do_I2C_IDLE(TWI_CONFIG* config)
{
	I2C_status.busy  = false; // Bus Free
	I2C_status.error = I2C_NOERR;
	return I2C_IDLE; // park the FSM on IDLE
}

static i2c_fsm_states_t I2C_do_I2C_SEND_RESTART_READ(TWI_CONFIG* config)
{
	return I2C_do_I2C_SEND_ADR_READ(config);
}

static i2c_fsm_states_t I2C_do_I2C_SEND_RESTART_WRITE(TWI_CONFIG* config)
{
	return I2C_do_I2C_SEND_ADR_WRITE(config);
}

static i2c_fsm_states_t I2C_do_I2C_SEND_RESTART(TWI_CONFIG* config)
{
	return I2C_do_I2C_SEND_ADR_READ(config);
}

static i2c_fsm_states_t I2C_do_I2C_SEND_STOP(TWI_CONFIG* config)
{
	config->MCTRLB.MCMD = TWI_MCMD_STOP_gc;
	setTwiMCTRLB(*config);
	return I2C_do_I2C_IDLE(config);
}

static i2c_fsm_states_t I2C_do_I2C_DO_ADDRESS_NACK(TWI_CONFIG* config)
{
	I2C_status.addressNACKCheck = 0;
	I2C_status.error            = I2C_FAIL;
	switch (I2C_status.callbackTable[i2c_addressNACK](I2C_status.callbackPayload[i2c_addressNACK])) {
		case i2c_restart_read:
		return I2C_do_I2C_SEND_RESTART_READ(config);
		case i2c_restart_write:
		return I2C_do_I2C_SEND_RESTART_WRITE(config);
		default:
		return I2C_do_I2C_SEND_STOP(config);
	}
}

static i2c_fsm_states_t I2C_do_I2C_SEND_ADR_READ(TWI_CONFIG* config)
{
	I2C_status.addressNACKCheck = 1;
	config->MADDR = I2C_status.address << 1 | 1;
	setTwiMADDR(*config);
	return I2C_RX;
}

static i2c_fsm_states_t I2C_do_I2C_SEND_ADR_WRITE(TWI_CONFIG* config)
{
	I2C_status.addressNACKCheck = 1;
	config->MADDR = I2C_status.address << 1;
	setTwiMADDR(*config);
	return I2C_TX;
}

static i2c_fsm_states_t I2C_do_I2C_RX_DO_ACK(TWI_CONFIG* config)
{
	config->MCTRLB.ACKACT = false;
	setTwiMCTRLB(*config);
	return I2C_RX;
}

static i2c_fsm_states_t I2C_do_I2C_TX_DO_ACK(TWI_CONFIG* config)
{
	config->MCTRLB.ACKACT = false;
	setTwiMCTRLB(*config);
	return I2C_TX;
}

static i2c_fsm_states_t I2C_do_I2C_DO_NACK_STOP(TWI_CONFIG* config)
{
	config->MCTRLB.ACKACT = true;
	config->MCTRLB.MCMD = true;
	setTwiMCTRLB(*config);
	return I2C_do_I2C_IDLE(config);
}

static i2c_fsm_states_t I2C_do_I2C_DO_NACK_RESTART(TWI_CONFIG* config)
{
	config->MCTRLB.ACKACT = true;
	setTwiMCTRLB(*config);
	return I2C_SEND_RESTART;
}

static i2c_fsm_states_t I2C_do_I2C_TX(TWI_CONFIG* config)
{
	if ((config->twi->MSTATUS & TWI_RXACK_bm)) // Slave replied with NACK
	{
		switch (I2C_status.callbackTable[i2c_dataNACK](I2C_status.callbackPayload[i2c_dataNACK])) {
			case i2c_restart_read:
			return I2C_do_I2C_SEND_RESTART_READ(config);
			case i2c_restart_write:
			return I2C_do_I2C_SEND_RESTART_WRITE(config);
			default:
			case i2c_continue:
			case i2c_stop:
			return I2C_do_I2C_SEND_STOP(config);
		}
		} else {
		I2C_status.addressNACKCheck = 0;
		config->MDATA = *I2C_status.data_ptr++;
		setTwiMDATA(*config);
		return (--I2C_status.data_length) ? I2C_TX : I2C_TX_EMPTY;
	}
}

static i2c_fsm_states_t I2C_do_I2C_RX(TWI_CONFIG* config)
{
	I2C_status.addressNACKCheck = 0;

	if (I2C_status.data_length == 1) 
	config->MCTRLB.ACKACT = true;
	else
	config->MCTRLB.ACKACT = false;
	
	setTwiMCTRLB(*config);
	
	if (--I2C_status.data_length) {
		*I2C_status.data_ptr = config->twi->MDATA;
		I2C_status.data_ptr++;
		config->MCTRLB.MCMD = TWI_MCMD_RECVTRANS_gc;
		setTwiMCTRLB(*config);
		return I2C_RX;
		} else {
		*I2C_status.data_ptr = config->twi->MDATA;
		I2C_status.data_ptr++;
		I2C_status.bufferFree = true;
		switch (I2C_status.callbackTable[i2c_dataComplete](I2C_status.callbackPayload[i2c_dataComplete])) {
			case i2c_restart_write:
			case i2c_restart_read:
			return I2C_do_I2C_DO_NACK_RESTART(config);
			default:
			case i2c_continue:
			case i2c_stop:
			return I2C_do_I2C_DO_NACK_STOP(config);
		}
	}
}


static i2c_fsm_states_t I2C_do_I2C_TX_EMPTY(TWI_CONFIG* config)
{
	if ((config->twi->MSTATUS & TWI_RXACK_bm)) // Slave replied with NACK
	{
		switch (I2C_status.callbackTable[i2c_dataNACK](I2C_status.callbackPayload[i2c_dataNACK])) {
			case i2c_restart_read:
			return I2C_do_I2C_SEND_RESTART_READ(config);
			case i2c_restart_write:
			return I2C_do_I2C_SEND_RESTART_WRITE(config);
			default:
			case i2c_continue:
			case i2c_stop:
			return I2C_do_I2C_SEND_STOP(config);
		}
		} else {
		I2C_status.bufferFree = true;
		switch (I2C_status.callbackTable[i2c_dataComplete](I2C_status.callbackPayload[i2c_dataComplete])) {
			case i2c_restart_read:
			return I2C_do_I2C_SEND_RESTART_READ(config);
			case i2c_restart_write:
			return I2C_do_I2C_SEND_RESTART_WRITE(config);
			case i2c_continue:
			return I2C_do_I2C_TX(config);
			default:
			case i2c_stop:
			return I2C_do_I2C_SEND_STOP(config);
		}
	}
}


static i2c_fsm_states_t I2C_do_I2C_BUS_COLLISION(TWI_CONFIG* config)
{
	// Clear bus collision status flag
	config->MSTATUS.ARBLOST = true;
	setTwiMSTATUS(*config);
	;
	I2C_status.error = I2C_FAIL;
	switch (I2C_status.callbackTable[i2c_writeCollision](I2C_status.callbackPayload[i2c_writeCollision])) {
		case i2c_restart_read:
		return I2C_do_I2C_SEND_RESTART_READ(config);
		case i2c_restart_write:
		return I2C_do_I2C_SEND_RESTART_WRITE(config);
		default:
		return I2C_do_I2C_RESET(config);
	}
}

static i2c_fsm_states_t I2C_do_I2C_BUS_ERROR(TWI_CONFIG* config)
{
	config->MCTRLB.FLUSH = true;
	setTwiMCTRLB(*config);
	
	config->MSTATUS.BUSSTATE = true;
	setTwiMSTATUS(*config);
	
	I2C_status.busy  = false;
	I2C_status.error = I2C_FAIL;
	return I2C_RESET; // park the FSM on reset
}

stateHandlerFunction *I2C_fsmStateTable[] = {
	I2C_do_I2C_IDLE,               // I2C_IDLE
	I2C_do_I2C_SEND_ADR_READ,      // I2C_SEND_ADR_READ
	I2C_do_I2C_SEND_ADR_WRITE,     // I2C_SEND_ADR_WRITE
	I2C_do_I2C_TX,                 // I2C_TX
	I2C_do_I2C_RX,                 // I2C_RX
	I2C_do_I2C_TX_EMPTY,           // I2C_TX_EMPTY
	I2C_do_I2C_SEND_RESTART_READ,  // I2C_SEND_RESTART_READ
	I2C_do_I2C_SEND_RESTART_WRITE, // I2C_SEND_RESTART_WRITE
	I2C_do_I2C_SEND_RESTART,       // I2C_SEND_RESTART
	I2C_do_I2C_SEND_STOP,          // I2C_SEND_STOP
	I2C_do_I2C_RX_DO_ACK,          // I2C_RX_DO_ACK
	I2C_do_I2C_TX_DO_ACK,          // I2C_TX_DO_ACK
	I2C_do_I2C_DO_NACK_STOP,       // I2C_RX_DO_NACK_STOP
	I2C_do_I2C_DO_NACK_RESTART,    // I2C_RX_DO_NACK_RESTART
	I2C_do_I2C_RESET,              // I2C_RESET
	I2C_do_I2C_DO_ADDRESS_NACK,    // I2C_ADDRESS_NACK
	I2C_do_I2C_BUS_COLLISION,      // I2C_BUS_COLLISION
	I2C_do_I2C_BUS_ERROR           // I2C_BUS_ERROR
};

void I2C_master_default_isr(TWI_CONFIG* config)
{
	config->MSTATUS.RIF = true;
	config->MSTATUS.WIF = true;
	setTwiMSTATUS(*config);

	// NOTE: We are ignoring the Write Collision flag.

	// Address phase received NACK from slave, override next state
	if (I2C_status.addressNACKCheck && (config->twi->MSTATUS & TWI_RXACK_bm)) {
		I2C_status.state = I2C_ADDRESS_NACK; // State Override
	}

	// Bus arbitration lost to another master, override next state
	if (config->twi->MSTATUS & TWI_ARBLOST_bm) {
		I2C_status.state = I2C_BUS_COLLISION; // State Override
	}

	// Bus error, override next state
	if (config->twi->MSTATUS & TWI_BUSERR_bm) {
		I2C_status.state = I2C_BUS_ERROR; // State Override
	}

	I2C_status.state = I2C_fsmStateTable[I2C_status.state](config);
}

static i2c_operations_t I2C_return_stop(void *p)
{
	return i2c_stop;
}

static i2c_operations_t I2C_return_reset(void *p)
{
	return i2c_reset_link;
}

static void I2C_set_callback(i2c_callback_index idx, i2c_callback cb, void *p) {
	if (cb) {
		I2C_status.callbackTable[idx]   = cb;
		I2C_status.callbackPayload[idx] = p;
		} else {
		I2C_status.callbackTable[idx]   = I2C_return_stop;
		I2C_status.callbackPayload[idx] = NULL;
	}
}