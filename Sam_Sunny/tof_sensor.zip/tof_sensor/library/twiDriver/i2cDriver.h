/*
 * i2cDriver.h
 *
 * Created: 10/23/2023 1:44:13 PM
 *  Author: BenSchnuck
 */ 


#ifndef I2CDRIVER_H_
#define I2CDRIVER_H_
#include "twiDriver.h"
#include "i2c_types.h"

#define I2C_TIMEOUT 10000

uint8_t     I2C_read1ByteRegister(TWI_CONFIG* config, i2c_address_t address, uint8_t reg);
uint16_t    I2C_read2ByteRegister(TWI_CONFIG* config, i2c_address_t address, uint8_t reg);
i2c_error_t I2C_write1ByteRegister(TWI_CONFIG* config, i2c_address_t address, uint8_t reg, uint8_t data);
i2c_error_t I2C_write2ByteRegister(TWI_CONFIG* config, i2c_address_t address, uint8_t reg, uint16_t data);

i2c_error_t I2C_writeNBytes(TWI_CONFIG* config, i2c_address_t address, void *data, size_t len);
i2c_error_t I2C_readDataBlock(TWI_CONFIG* config, i2c_address_t address, uint8_t reg, void *data, size_t len);
i2c_error_t I2C_readNBytes(TWI_CONFIG* config, i2c_address_t address, void *data, size_t len);


#endif /* I2CDRIVER_H_ */