/*
 * usartSlave.h
 *
 * Created: 12/23/2023 12:18:21 PM
 *  Author: PramodVariyam
 */ 


#ifndef USARTSLAVE_H_
#define USARTSLAVE_H_

typedef void (*process_cmd_cb_t)(void);

typedef enum {
	UART_SLAVE_IDLE=0,
	UART_SLAVE_RECEIVING = 1,
	UART_SLAVE_PROCESSING=2,
} UartSlaveState;

typedef struct {
	uint8_t num_cmd_params;
	uint8_t num_resp_params;
	process_cmd_cb_t actions_function;
}SlaveCommand;

typedef struct {
	USART_CONFIG* uart_config;
	UartSlaveState state;
	uint8_t num_bytes_received;
	uint8_t command_index;
	uint8_t parameter[256];
	uint8_t response[256];
	SlaveCommand commands[64];
}SlaveUartData;

extern SlaveUartData SLAVE_DATA;

void slave_uart_initialize(USART_CONFIG* thisUart);
void slave_uart_add_command(uint8_t cmd_index, uint8_t num_cmd_params, uint8_t num_resp_params, process_cmd_cb_t cb_fn);
void process_uart_command();
void slave_uart_default_tx_isr();
void slave_uart_default_rx_isr();

#endif /* USARTSLAVE_H_ */