/*
 * tcaDriver.h
 *
 * Created: 10/16/2023 3:28:44 PM
 *  Author: BenSchnuck
 */ 


#ifndef TCADRIVER_H_
#define TCADRIVER_H_

//////////////////////////////////////////////////////////////////////////
// single structures
//////////////////////////////////////////////////////////////////////////
/*
	Config object for CTRLA register of TCA - Single Mode
*/
typedef struct {
	bool ENABLE;
	TCA_SINGLE_CLKSEL_t CLKSEL;
}TCA_SINGLE_CTRLA;

/*
	Config object for CTRLB register of TCA - Single Mode
*/
typedef struct {
	bool CMP2EN;
	bool CMP1EN;
	bool CMP0EN;
	bool ALUPD;
	TCA_SINGLE_WGMODE_t WGMODE;
}TCA_SINGLE_CTRLB;

/*
	Config object for CTRLC register of TCA - Single Mode
*/
typedef struct {
	bool CMP2OV;
	bool CMP1OV;
	bool CMP0OV;
}TCA_SINGLE_CTRLC;

/*
	Config object for CTRLD register of TCA - Single Mode
*/
typedef struct {
	bool SPLITM;
}TCA_SINGLE_CTRLD;

/*
	Config object for CTRLECLR register of TCA - Single Mode
*/
typedef struct {
	TCA_SINGLE_CMD_t CMD;
	bool LUPD;
	bool DIR;
}TCA_SINGLE_CTRLECLR;

/*
	Config object for CTRLESET register of TCA - Single Mode
*/
typedef struct {
	TCA_SINGLE_CMD_t CMD;
	bool LUPD;
	bool DIR;
}TCA_SINGLE_CTRLESET;

/*
	Config object for CTRLFCLR register of TCA - Single Mode
*/
typedef struct {
	bool CMP2BV;
	bool CMP1BV;
	bool CMP0BV;
	bool PERBV;
}TCA_SINGLE_CTRLFCLR;

/*
	Config object for CTRLFSET register of TCA - Single Mode
*/
typedef struct {
	bool CMP2BV;
	bool CMP1BV;
	bool CMP0BV;
	bool PERBV;
}TCA_SINGLE_CTRLFSET;

/*
	Config object for EVCTRL register of TCA - Single Mode
*/
typedef struct {
	TCA_SINGLE_EVACT_t EVACT;
	bool CNTEI;
}TCA_SINGLE_EVCTRL;

/*
	Config object for INTCTRL register of TCA - Single Mode
*/
typedef struct {
	bool CMP2;
	bool CMP1;
	bool CMP0;
	bool OVF;
}TCA_SINGLE_INTCTRL;

//////////////////////////////////////////////////////////////////////////
// split structures
//////////////////////////////////////////////////////////////////////////
/*
	Config object for CTRLA register of TCA - Split Mode
*/
typedef struct {
	bool ENABLE;
	TCA_SPLIT_CLKSEL_t CLKSEL;
}TCA_SPLIT_CTRLA;

/*
	Config object for CTRLB register of TCA - Split Mode
*/
typedef struct {
	bool HCMP2EN;
	bool HCMP1EN;
	bool HCMP0EN;
	bool LCMP2EN;
	bool LCMP1EN;
	bool LCMP0EN;
}TCA_SPLIT_CTRLB;

/*
	Config object for CTRLC register of TCA - Split Mode
*/
typedef struct {
	bool HCMP2OV;
	bool HCMP1OV;
	bool HCMP0OV;
	bool LCMP2OV;
	bool LCMP1OV;
	bool LCMP0OV;
}TCA_SPLIT_CTRLC;

/*
	Config object for CTRLD register of TCA - Split Mode
*/
typedef struct {
	bool SPLITM;
}TCA_SPLIT_CTRLD;

/*
	Config object for CTRLECLR register of TCA - Split Mode
*/
typedef struct {
	TCA_SPLIT_CMD_t CMD;
	uint8_t CMDEN:2;
}TCA_SPLIT_CTRLECLR;

/*
	Config object for CTRLESET register of TCA - Split Mode
*/
typedef struct {
	TCA_SPLIT_CMD_t CMD;
	uint8_t CMDEN:2;
}TCA_SPLIT_CTRLESET;

/*
	Config object for INTCTRL register of TCA - Split Mode
*/
typedef struct {
	bool LCMP2;
	bool LCMP1;
	bool LCMP0;
	bool HUNF;
	bool LUNF;	
}TCA_SPLIT_INTCTRL;

/*
	Config object for TCA - Single Mode
*/
typedef struct {
	TCA_SINGLE_CTRLA CTRLA;
	TCA_SINGLE_CTRLB CTRLB;
	TCA_SINGLE_CTRLC CTRLC;
	TCA_SINGLE_CTRLD CTRLD;
	TCA_SINGLE_CTRLECLR CTRLECLR;
	TCA_SINGLE_CTRLESET CTRLESET;
	TCA_SINGLE_CTRLFCLR CTRLFCLR;
	TCA_SINGLE_CTRLFSET CTRLFSET;
	TCA_SINGLE_EVCTRL EVCTRL;
	TCA_SINGLE_INTCTRL INTCTRL;
	bool DBGCTRL;
	uint8_t TEMP;
	uint16_t CNT;
	uint16_t PER;
	uint16_t CMP0;
	uint16_t CMP1;
	uint16_t CMP2;
	uint16_t PERBUF;
	uint8_t PERBUFH;
	uint16_t CMP0nBUF;
	uint16_t CMP1nBUF;
	uint16_t CMP2nBUF;
}TCA_SINGLE_CONFIG;

/*
	Config object for TCA - Split Mode
*/
typedef struct {
	TCA_SPLIT_CTRLA CTRLA;
	TCA_SPLIT_CTRLB CTRLB;
	TCA_SPLIT_CTRLC CTRLC;
	TCA_SPLIT_CTRLD CTRLD;
	TCA_SPLIT_CTRLECLR CTRLECLR;
	TCA_SPLIT_CTRLESET CTRLESET;
	TCA_SPLIT_INTCTRL INTCTRL;
	bool DBGCTRL;
	uint8_t LCNT;
	uint8_t HCNT;
	uint8_t LPER;
	uint8_t HPER;
	uint8_t LCMP0;
	uint8_t HCMP0;
	uint8_t LCMP1;
	uint8_t HCMP1;
	uint8_t LCMP2;
	uint8_t HCMP2;
}TCA_SPLIT_CONFIG;

/*
	Config object for TCA
*/
typedef struct {
	bool split_mode;
	TCA_t* tca;
	
	// single
	TCA_SINGLE_CONFIG SINGLE;
	
	// split
	TCA_SPLIT_CONFIG SPLIT;
}TCA_CONFIG;

void setTcaCTRLD(TCA_CONFIG config);
void enableTcaSplitMode(TCA_CONFIG config, bool enable);
void setTcaCTRLA(TCA_CONFIG config);
void setTcaCTRLB(TCA_CONFIG config);
void setTcaCTRLC(TCA_CONFIG config);
void setTcaCTRLECLR(TCA_CONFIG config);
void setTcaCTRLESET(TCA_CONFIG config);
void setTcaCTRLFCLR(TCA_CONFIG config);
void setTcaCTRLFSET(TCA_CONFIG config);
void setTcaEVCTRL(TCA_CONFIG config);
void setTcaINTCTRL(TCA_CONFIG config);
void resetTcaINTFLAGS_CMP(TCA_CONFIG config, uint8_t CMP_NUM);
void resetTcaINTFLAGS_OVF(TCA_CONFIG config, uint8_t OVF_NUM);
void resetTcaINTFLAGS(TCA_CONFIG config);
void setTcaDBGCTRL(TCA_CONFIG config);
void setTcaTEMP(TCA_CONFIG config);
void setTcaCNT(TCA_CONFIG config);
void setTcaPER(TCA_CONFIG config);
void setTcaCMP0(TCA_CONFIG config);
void setTcaCMP1(TCA_CONFIG config);
void setTcaCMP2(TCA_CONFIG config);
void setTcaPERBUF(TCA_CONFIG config);
void setTcaPERBUFH(TCA_CONFIG config);
void setTcaCMP0BUF(TCA_CONFIG config);
void setTcaCMP1BUF(TCA_CONFIG config);
void setTcaCMP2BUF(TCA_CONFIG config);

void instantiateTCA(TCA_t* tca, TCA_CONFIG* tca_config, bool split_mode);
void initializeWaveformTCA(TCA_CONFIG* config, TCA_SINGLE_WGMODE_t wgmode,  uint16_t CMP, PIN_OBJ outputPin);
void startWaveformTCA(TCA_CONFIG* config, uint8_t channel);
void stopWaveformTCA(TCA_CONFIG* config);

void setWaveformTopTCA(TCA_CONFIG* config, uint16_t CMP);
void setWaveformIntTCA(TCA_CONFIG* config, uint8_t channel, bool enable);

void initializePeriodicIntTCA(TCA_CONFIG* config, uint16_t timeout);
void startPeriodicTCA(TCA_CONFIG* config);
void stopPeriodicTCA(TCA_CONFIG* config);

#endif /* TCADRIVER_H_ */