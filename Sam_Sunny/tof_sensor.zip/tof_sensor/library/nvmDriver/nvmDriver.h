/*
 * nvmDriver.h
 *
 * Created: 12/21/2023 3:29:56 PM
 *  Author: BenSchnuck
 */ 


#ifndef NVMDRIVER_H_
#define NVMDRIVER_H_

#include "util.h"

#define BOOTLOADER_SECTION __attribute__((section(".bootloader")))

#ifdef __cplusplus
extern "C" {
#endif

/** Datatype for flash address */
typedef uint16_t flash_adr_t;

/** Datatype for EEPROM address */
typedef uint16_t eeprom_adr_t;

/** Datatype for return status of NVMCTRL operations */
typedef enum {
	NVM_OK    = 0, ///< NVMCTRL free, no write ongoing.
	NVM_ERROR = 1, ///< NVMCTRL operation retsulted in error
	NVM_BUSY  = 2, ///< NVMCTRL busy, write ongoing.
} nvmctrl_status_t;

int8_t FLASH_init();

uint8_t FLASH_read_eeprom_byte(eeprom_adr_t eeprom_adr);

nvmctrl_status_t FLASH_write_eeprom_byte(eeprom_adr_t eeprom_adr, uint8_t data);

void FLASH_read_eeprom_block(eeprom_adr_t eeprom_adr, uint8_t *data, size_t size);

nvmctrl_status_t FLASH_write_eeprom_block(eeprom_adr_t eeprom_adr, uint8_t *data, size_t size);

bool FLASH_is_eeprom_ready();

uint8_t FLASH_read_flash_byte(flash_adr_t flash_adr);

nvmctrl_status_t FLASH_write_flash_byte(flash_adr_t flash_adr, uint8_t *ram_buffer, uint8_t data);

nvmctrl_status_t FLASH_erase_flash_page(flash_adr_t flash_adr);

nvmctrl_status_t FLASH_write_flash_page(flash_adr_t flash_adr, uint8_t *data);

nvmctrl_status_t FLASH_write_flash_block(flash_adr_t flash_adr, uint8_t *data, size_t size, uint8_t *ram_buffer);

nvmctrl_status_t FLASH_write_flash_stream(flash_adr_t flash_adr, uint8_t data, bool finalize);

#ifdef __cplusplus
}
#endif

#endif /* NVMDRIVER_H_ */