/*
 * util.h
 *
 * Created: 12/21/2023 3:11:09 PM
 *  Author: BenSchnuck
 */ 


#ifndef UTIL_H_
#define UTIL_H_

// THIS DRIVER MUST BE PART OF A PROJECT WITH SYSTEMDRIVER IN ORDER TO WORK
#include "../systemDriver/utils/compiler.h"
#include "../systemDriver/utils/ccp.h"
#include <stdint.h>
#include <string.h>
#include <stdbool.h>

#endif /* UTIL_H_ */