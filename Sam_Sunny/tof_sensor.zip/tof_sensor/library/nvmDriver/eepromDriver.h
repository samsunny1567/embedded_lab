/*
 * eepromDriver.h
 *
 * Created: 12/21/2023 3:41:14 PM
 *  Author: BenSchnuck
 */ 


#ifndef EEPROMDRIVER_H_
#define EEPROMDRIVER_H_

#define ERROR_ATMEGA_EEPROM_NONE 0
#define ERROR_ATMEGA_EEPROM_BASE 30
#define ERROR_ATMEGA_EEPROM_WRITE 1

#include "util.h"

typedef struct
{
	uint8_t address;
	uint8_t length;
} EepromRegister;
uint8_t write_eeprom(EepromRegister * reg, uint8_t *data, uint8_t dataLength, uint8_t padChar);
uint8_t read_eeprom(EepromRegister * reg, uint8_t *data);
void instantiate_eeprom_reg(EepromRegister* reg, uint8_t address, uint8_t length);


#endif /* EEPROMDRIVER_H_ */